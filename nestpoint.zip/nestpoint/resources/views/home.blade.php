@extends('layouts.site')
@section('title', 'NestPoint | Find your place in Zambia')
@section('content')
<section class="hero">
    <div class="hero-photo" role="img" aria-label="Elegant modern home exterior"></div>
    <div class="hero-overlay"></div>
    <div class="container hero-content">
        <div class="eyebrow light"><span class="eyebrow-line"></span> A BETTER WAY TO FEEL AT HOME</div>
        <h1>Find a place<br>to call <em>yours.</em></h1>
        <p>Beautiful spaces. Better beginnings. Explore exceptional homes and properties across Zambia.</p>
        <a class="button button-cream" href="#properties">Explore properties <span>↗</span></a>
        <div class="hero-stats"><div><strong>06</strong><span>Curated listings</span></div><div><strong>03</strong><span>Zambian cities</span></div><div><strong>100%</strong><span>Made for your search</span></div></div>
    </div>
    <div class="hero-side-note">DISCOVER YOUR NEXT CHAPTER <span>↘</span></div>
</section>

<section class="search-section" id="properties">
    <div class="container">
        <div class="search-heading"><div><div class="eyebrow">FIND YOUR PERFECT FIT</div><h2>Places worth <em>exploring.</em></h2><p>From quiet corners to vibrant city living, discover the one that feels right.</p></div><div class="listing-total">{{ $properties->count() }} {{ Str::plural('property', $properties->count()) }} found</div></div>
        <form class="search-panel" method="GET" action="{{ route('home') }}#properties">
            <label class="search-field search-keyword"><span>LOCATION OR KEYWORD</span><input type="search" name="search" placeholder="Where would you like to live?" value="{{ request('search') }}"></label>
            <label class="search-field"><span>LOOKING TO</span><select name="purpose"><option value="">Buy or rent</option><option value="Sale" @selected(request('purpose') === 'Sale')>Buy</option><option value="Rent" @selected(request('purpose') === 'Rent')>Rent</option></select></label>
            <label class="search-field"><span>PROPERTY TYPE</span><select name="type"><option value="">All properties</option><option value="House" @selected(request('type') === 'House')>House</option><option value="Apartment" @selected(request('type') === 'Apartment')>Apartment</option></select></label>
            <button class="button search-btn" type="submit">Search <span>↗</span></button>
        </form>
        <div class="filter-row"><span>POPULAR SEARCHES</span><a href="{{ route('home') }}?city=Lusaka#properties">Lusaka ↗</a><a href="{{ route('home') }}?city=Ndola#properties">Ndola ↗</a><a href="{{ route('home') }}?purpose=Rent#properties">For rent ↗</a><a href="{{ route('home') }}#properties">View all ↗</a></div>

        @if($properties->isEmpty())
            <div class="empty-state"><h3>No matching properties yet.</h3><p>Try another location, property type or search term.</p><a class="button" href="{{ route('home') }}#properties">Clear filters ↗</a></div>
        @else
            <div class="property-grid">
                @foreach($properties as $property)
                    <article class="property-card">
                        <a class="property-photo" href="{{ route('properties.show', $property['slug']) }}"><img src="{{ $property['image'] }}" alt="{{ $property['title'] }} property photo" loading="lazy"><span class="property-badge">{{ $property['purpose'] === 'Sale' ? 'FOR SALE' : 'FOR RENT' }}</span><span class="photo-arrow">↗</span></a>
                        <div class="property-body"><span class="property-location">⌖ {{ $property['location'] }}</span><div class="property-price">K {{ number_format($property['price']) }} <small>{{ $property['purpose'] === 'Rent' ? '/ month' : '' }}</small></div><h3><a href="{{ route('properties.show', $property['slug']) }}">{{ $property['title'] }}</a></h3><div class="property-meta"><span>▦ {{ $property['beds'] }} Beds</span><span>◉ {{ $property['baths'] }} Baths</span><span>□ {{ $property['area'] }} m²</span></div></div>
                    </article>
                @endforeach
            </div>
        @endif
    </div>
</section>

<section class="feature-section" id="why-us"><div class="container feature-grid"><div class="feature-photo"><img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85" alt="Inviting contemporary living room" loading="lazy"><span class="feature-caption">THE ART OF FEELING AT HOME</span></div><div class="feature-copy"><div class="eyebrow">MORE THAN FOUR WALLS</div><h2>Your next chapter starts <em>here.</em></h2><p>Finding home should feel exciting, not overwhelming. NestPoint brings thoughtfully selected properties together in one calm, easy-to-use space.</p><div class="feature-point"><span>01</span><div><h3>Thoughtfully curated</h3><p>Explore clear details, beautiful imagery and homes that stand out.</p></div></div><div class="feature-point"><span>02</span><div><h3>Explore your way</h3><p>Search by neighbourhood, property type or how you want to live.</p></div></div><a class="text-link" href="#properties">Discover available homes <span>↗</span></a></div></div></section>
<section class="closing"><div class="container"><span class="eyebrow light">YOUR SPACE IS OUT THERE</span><h2>Somewhere wonderful<br>is waiting for <em>you.</em></h2><a class="button button-cream" href="#properties">Browse properties ↗</a></div></section>
@endsection
