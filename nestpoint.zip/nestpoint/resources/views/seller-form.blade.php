@extends('layouts.site')
@section('title','List a Property | NestPoint')
@section('content')
<section class="detail-section"><div class="container" style="max-width:760px"><a href="{{ route('seller.index') }}" class="back-link">← My properties</a><div class="eyebrow">SELL ON NESTPOINT</div><h1>{{ $property?'Edit your listing':'List your property' }}</h1><p>Listings go through an admin review before publication. Commission applies only to verified sales facilitated through NestPoint; the rate shown in your dashboard is illustrative until agreed in writing.</p>
<form class="enquiry-box admin-form" method="POST" action="{{ $property?route('seller.update',$property):route('seller.store') }}">@csrf @if($property)@method('PUT')@endif
@foreach(['title'=>'Property name','location'=>'Neighbourhood / address area','city'=>'City','image'=>'Photo URL (https)'] as $name=>$label)<label>{{ $label }}<input name="{{ $name }}" required value="{{ old($name,$property?->$name) }}"></label>@endforeach
<div class="admin-two"><label>Type<select name="type">@foreach(['House','Apartment','Commercial'] as $v)<option @selected(old('type',$property?->type)===$v)>{{ $v }}</option>@endforeach</select></label><label>Listing type<select name="purpose">@foreach(['Sale','Rent'] as $v)<option @selected(old('purpose',$property?->purpose)===$v)>{{ $v }}</option>@endforeach</select></label></div>
<div class="admin-two">@foreach(['price'=>'Asking price ZMW','beds'=>'Bedrooms','baths'=>'Bathrooms','area'=>'Floor area m²'] as $name=>$label)<label>{{ $label }}<input required type="number" min="{{ in_array($name,['beds','baths'])?0:1 }}" name="{{ $name }}" value="{{ old($name,$property?->$name ?? 1) }}"></label>@endforeach</div>
<label>Description<textarea name="description" rows="5" required>{{ old('description',$property?->description) }}</textarea></label>
<label class="inline-check"><input required type="checkbox" name="accept_terms" value="1"> I confirm I have authority to advertise this property and understand that a separate written agency/commission agreement is required before a commission can become payable.</label>
@if($errors->any())<div class="form-errors">@foreach($errors->all() as $error)<p>{{ $error }}</p>@endforeach</div>@endif
<button class="button" type="submit">{{ $property?'Submit changes for approval':'Submit listing for approval' }}</button></form></div></section>
@endsection