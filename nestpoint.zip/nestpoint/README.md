# NestPoint — Real Estate Listings and Viewing Requests

NestPoint is a Laravel 13 + SQLite property discovery MVP designed for Zambia.

## Features
- Responsive real estate landing page and searchable properties (city, keyword, sale/rent, type).
- Six clearly **illustrative** seeded example listings, not verified advertisements.
- Listing details, account registration/login/logout, and authenticated property viewing requests.
- My Viewings history, request cancellation, and basic conflicting-time rejection.
- Admin-only management for property creation, editing, publishing/unpublishing, and reviewing viewing statuses.
- CSRF protection, session authentication, ownership checks, and server-side validation.

## Local installation
1. Install PHP 8.3+, Composer and SQLite support.
2. Run `composer install`.
3. Copy `.env.example` to `.env` and run `php artisan key:generate`.
4. Configure `DB_CONNECTION=sqlite` and ensure `database/database.sqlite` exists (create an empty file if necessary).
5. Run `php artisan migrate --seed`.
6. Run `php artisan serve --port=8015` and open http://127.0.0.1:8015.

CSS and JavaScript are served directly from `public`; Node builds are not required for the custom pages.

## Creating an administrator
1. Register a normal account in the browser.
2. In your trusted local terminal run `php artisan nestpoint:make-admin your-email@example.com`.
3. Confirm the interactive prompt.
4. Sign in and select **Admin** in the navigation.

No default administrator credentials or passwords are seeded.

## Development status and limitations
This is a portfolio MVP, not a live real estate marketplace. Property prices, locations, imagery, and availability are sample data. Photos are loaded from Unsplash; internet access is required for them. Contact is not yet configured as an operational enquiry email. Viewing requests are stored but **no notification email is sent**. The scheduling conflict check is sequential and does not yet guarantee atomic conflict prevention during simultaneous requests. Production deployment also requires file/image ownership rights, stricter operational controls, and end-to-end accessibility/security review.

## Tests
Run `php artisan test`. Feature tests use a separate in-memory SQLite database via RefreshDatabase and do not alter the local site data.

## Security
Never commit `.env`, `database/database.sqlite`, or customer data to GitHub. Laravel's .gitignore should protect them. Use HTTPS and APP_DEBUG=false in production.

## Seller and agency workflows
Owners can submit properties for moderation, edit their available listings and report completed sales. Administrators review listings, verify reported sales and mark commission status. Example rate is 3%, configurable on the listing. Demo transactions are not actual payments.

