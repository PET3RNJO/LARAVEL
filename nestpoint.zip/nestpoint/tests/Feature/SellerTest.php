<?php
namespace Tests\Feature;
use App\Models\Property;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
class SellerTest extends TestCase {
 use RefreshDatabase;
 private function data():array{return ['title'=>'New Seller Home','location'=>'Roma, Lusaka','city'=>'Lusaka','type'=>'House','purpose'=>'Sale','price'=>900000,'beds'=>3,'baths'=>2,'area'=>180,'image'=>'https://example.com/photo.jpg','description'=>'Sample property for seller tests.','accept_terms'=>'1'];}
 public function test_guest_must_sign_in_to_list_property():void{$this->get('/list-property')->assertRedirect('/login');}
 public function test_owner_submission_is_private_until_review():void{$owner=User::factory()->create();$this->actingAs($owner)->post('/list-property',$this->data())->assertRedirect('/my-properties');$p=Property::firstOrFail();$this->assertSame('pending',$p->review_status);$this->assertFalse($p->active);$this->get('/properties/'.$p->slug)->assertNotFound();}
 public function test_other_user_cannot_edit_or_report_sale():void{$owner=User::factory()->create();$other=User::factory()->create();$this->actingAs($owner)->post('/list-property',$this->data());$p=Property::firstOrFail();$this->actingAs($other)->get('/my-properties/'.$p->id.'/edit')->assertForbidden();$this->actingAs($other)->patch('/my-properties/'.$p->id.'/report-sale',['agreed_sale_price'=>800000,'sale_reference'=>'Signed agreement'])->assertForbidden();}
 public function test_admin_approves_and_verifies_sale_and_tracks_commission():void{$owner=User::factory()->create();$admin=User::factory()->create(['is_admin'=>true]);$this->actingAs($owner)->post('/list-property',$this->data());$p=Property::firstOrFail();$this->actingAs($admin)->patch('/admin/properties/'.$p->id.'/review',['review_status'=>'approved','commission_rate'=>'3.00'])->assertRedirect();$this->assertTrue($p->fresh()->active);$this->actingAs($owner)->patch('/my-properties/'.$p->id.'/report-sale',['agreed_sale_price'=>800000,'sale_reference'=>'Completed signed sale agreement'])->assertRedirect();$this->assertEquals('reported',$p->fresh()->sale_status);$this->actingAs($admin)->patch('/admin/properties/'.$p->id.'/verify-sale',['decision'=>'verified'])->assertRedirect();$this->assertEquals(24000,$p->fresh()->commission_amount);$this->assertEquals('due',$p->fresh()->commission_status);$this->actingAs($admin)->patch('/admin/properties/'.$p->id.'/commission-paid')->assertRedirect();$this->assertEquals('paid',$p->fresh()->commission_status);}
}