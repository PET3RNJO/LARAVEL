<?php
namespace Tests\Feature;
use App\Models\Property;
use App\Models\User;
use App\Models\Viewing;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
class NestPointTest extends TestCase{
 use RefreshDatabase;
 private function property():Property{return Property::create(['slug'=>'test-home','title'=>'Test Home','location'=>'Roma, Lusaka','city'=>'Lusaka','type'=>'House','purpose'=>'Sale','price'=>500000,'beds'=>2,'baths'=>1,'area'=>100,'image'=>'https://example.com/house.jpg','description'=>'Demo property','active'=>true]);}
 public function test_listing_and_detail_are_public():void{$p=$this->property();$this->get('/')->assertOk()->assertSee('Test Home');$this->get('/properties/test-home')->assertOk()->assertSee('Test Home');}
 public function test_viewings_require_login():void{$p=$this->property();$this->get('/my-viewings')->assertRedirect('/login');$this->post('/properties/'.$p->id.'/viewings',[])->assertRedirect('/login');}
 public function test_registered_user_can_request_and_cancel_viewing():void{$p=$this->property();$u=User::factory()->create();$d=['viewing_date'=>now('Africa/Lusaka')->addDays(4)->toDateString(),'viewing_time'=>'10:00'];$this->actingAs($u)->post('/properties/'.$p->id.'/viewings',$d)->assertRedirect('/my-viewings');$v=Viewing::firstOrFail();$this->assertEquals('pending',$v->status);$this->actingAs($u)->patch('/my-viewings/'.$v->id.'/cancel')->assertRedirect();$this->assertEquals('cancelled',$v->fresh()->status);}
 public function test_other_user_cannot_cancel_viewing():void{$p=$this->property();$u=User::factory()->create();$other=User::factory()->create();$v=Viewing::create(['user_id'=>$u->id,'property_id'=>$p->id,'viewing_date'=>now()->addDays(5)->toDateString(),'viewing_time'=>'10:00','status'=>'pending']);$this->actingAs($other)->patch('/my-viewings/'.$v->id.'/cancel')->assertForbidden();}
 public function test_admin_area_denies_normal_users():void{$this->actingAs(User::factory()->create())->get('/admin/properties')->assertForbidden();}
 public function test_admin_can_open_dashboard():void{$u=User::factory()->create();$u->is_admin=true;$u->save();$this->actingAs($u)->get('/admin/properties')->assertOk();}
}