<?php
namespace Database\Seeders;
use App\Models\Property;
use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder{
 public function run():void{
 $data=[
 ['kabulonga-modern-villa','The Kabulonga Residence','Kabulonga, Lusaka','Lusaka','House','Sale',2850000,4,3,340,'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=85','A contemporary family home with open living spaces and a private garden.'],
 ['roma-garden-apartment','Roma Garden Apartment','Roma, Lusaka','Lusaka','Apartment','Rent',14500,3,2,165,'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85','Bright interiors, easy entertaining and a convenient location.'],
 ['ibex-hill-sanctuary','Ibex Hill Sanctuary','Ibex Hill, Lusaka','Lusaka','House','Sale',1950000,3,2,245,'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=85','A tranquil sunlit residence with generous indoor-outdoor space.'],
 ['woodlands-city-loft','Woodlands City Loft','Woodlands, Lusaka','Lusaka','Apartment','Rent',9500,2,2,110,'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85','Comfortable proportions and a fresh palette define this city apartment.'],
 ['ndola-family-escape','Ndola Family Escape','Kansenshi, Ndola','Ndola','House','Sale',1250000,4,2,280,'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&w=1200&q=85','Room to grow surrounded by mature greenery.'],
 ['kitwe-urban-suite','Kitwe Urban Suite','Parklands, Kitwe','Kitwe','Apartment','Rent',6800,2,1,95,'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85','A practical and beautifully styled home within easy reach of amenities.'],
 ];foreach($data as $d){Property::updateOrCreate(['slug'=>$d[0]],['title'=>$d[1],'location'=>$d[2],'city'=>$d[3],'type'=>$d[4],'purpose'=>$d[5],'price'=>$d[6],'beds'=>$d[7],'baths'=>$d[8],'area'=>$d[9],'image'=>$d[10],'description'=>$d[11],'featured'=>in_array($d[0],['kabulonga-modern-villa','roma-garden-apartment'])]);}
 }
}