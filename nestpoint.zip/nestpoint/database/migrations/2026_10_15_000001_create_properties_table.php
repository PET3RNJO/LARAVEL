<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {Schema::create('properties',function(Blueprint $t){$t->id();$t->string('slug')->unique();$t->string('title');$t->string('location');$t->string('city');$t->string('type');$t->string('purpose');$t->unsignedBigInteger('price');$t->unsignedSmallInteger('beds');$t->unsignedSmallInteger('baths');$t->unsignedInteger('area');$t->string('image');$t->text('description');$t->boolean('featured')->default(false);$t->boolean('active')->default(true);$t->timestamps();});}
 public function down(): void {Schema::dropIfExists('properties');}
};