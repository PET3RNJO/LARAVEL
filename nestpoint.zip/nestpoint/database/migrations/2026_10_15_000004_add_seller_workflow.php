<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
 Schema::table('properties',function(Blueprint $t){$t->foreignId('owner_id')->nullable()->constrained('users')->nullOnDelete();$t->string('review_status')->default('approved');$t->string('sale_status')->default('available');$t->unsignedBigInteger('agreed_sale_price')->nullable();$t->date('sold_at')->nullable();$t->decimal('commission_rate',5,2)->default(3.00);$t->unsignedBigInteger('commission_amount')->nullable();$t->string('commission_status')->default('not_due');$t->text('sale_reference')->nullable();});
 }
 public function down():void {Schema::table('properties',function(Blueprint $t){$t->dropForeign(['owner_id']);$t->dropColumn(['owner_id','review_status','sale_status','agreed_sale_price','sold_at','commission_rate','commission_amount','commission_status','sale_reference']);});}
};