<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {Schema::create('viewings',function(Blueprint $t){$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->foreignId('property_id')->constrained()->cascadeOnDelete();$t->date('viewing_date');$t->time('viewing_time');$t->text('message')->nullable();$t->string('status')->default('pending');$t->timestamps();$t->index(['property_id','viewing_date','viewing_time']);});}
 public function down():void {Schema::dropIfExists('viewings');}
};