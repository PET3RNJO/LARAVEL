<?php
use App\Models\User;
use Illuminate\Support\Facades\Artisan;
Artisan::command('nestpoint:make-admin {email}', function(string $email) {
 $user=User::where('email',$email)->first();
 if(!$user){$this->error('Account not found. Register on NestPoint first.');return 1;}
 if(!$this->confirm('Grant administrator privileges to '.$user->email.'?',false)){$this->warn('No changes made.');return 1;}
 $user->forceFill(['is_admin'=>true])->save();
 $this->info('Administrator access granted to '.$user->email);
 return 0;
})->purpose('Promote an existing user to NestPoint administrator');
