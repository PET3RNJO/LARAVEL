<?php
use App\Http\Controllers\PropertyController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ViewingController;
use App\Http\Controllers\AdminPropertyController;
use App\Http\Controllers\SellerPropertyController;
use Illuminate\Support\Facades\Route;
Route::get('/',[PropertyController::class,'index'])->name('home');
Route::get('/properties/{slug}',[PropertyController::class,'show'])->name('properties.show');
Route::middleware('guest')->group(function(){
 Route::get('/register',[AuthController::class,'registerForm'])->name('register');
 Route::post('/register',[AuthController::class,'register'])->name('register.store');
 Route::get('/login',[AuthController::class,'loginForm'])->name('login');
 Route::post('/login',[AuthController::class,'login'])->name('login.store');
});
Route::middleware('auth')->group(function(){
 Route::post('/logout',[AuthController::class,'logout'])->name('logout');
 Route::get('/my-properties',[SellerPropertyController::class,'index'])->name('seller.index');
 Route::get('/list-property',[SellerPropertyController::class,'create'])->name('seller.create');
 Route::post('/list-property',[SellerPropertyController::class,'store'])->name('seller.store');
 Route::get('/my-properties/{property}/edit',[SellerPropertyController::class,'edit'])->name('seller.edit');
 Route::put('/my-properties/{property}',[SellerPropertyController::class,'update'])->name('seller.update');
 Route::patch('/my-properties/{property}/report-sale',[SellerPropertyController::class,'reportSale'])->name('seller.report-sale');
 Route::patch('/admin/properties/{property}/review',[AdminPropertyController::class,'review'])->name('admin.review');
 Route::patch('/admin/properties/{property}/verify-sale',[AdminPropertyController::class,'verifySale'])->name('admin.verify-sale');
 Route::patch('/admin/properties/{property}/commission-paid',[AdminPropertyController::class,'commissionPaid'])->name('admin.commission-paid');
 Route::get('/my-viewings',[ViewingController::class,'index'])->name('viewings.index');
 Route::post('/properties/{property}/viewings',[ViewingController::class,'store'])->name('viewings.store');
 Route::patch('/my-viewings/{viewing}/cancel',[ViewingController::class,'cancel'])->name('viewings.cancel');
 Route::get('/admin/properties',[AdminPropertyController::class,'index'])->name('admin.index');
 Route::get('/admin/properties/{property}/edit',[AdminPropertyController::class,'edit'])->name('admin.edit');
 Route::post('/admin/properties',[AdminPropertyController::class,'store'])->name('admin.store');
 Route::put('/admin/properties/{property}',[AdminPropertyController::class,'update'])->name('admin.update');
 Route::patch('/admin/properties/{property}/unpublish',[AdminPropertyController::class,'destroy'])->name('admin.destroy');
 Route::patch('/admin/viewings/{viewing}',[AdminPropertyController::class,'viewingStatus'])->name('admin.viewings.update');
});
