<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;
class AuthController extends Controller{
 public function registerForm(){return view('auth', ['mode'=>'register']);}
 public function loginForm(){return view('auth', ['mode'=>'login']);}
 public function register(Request $r){$d=$r->validate(['name'=>'required|string|max:100','email'=>'required|email|max:255|unique:users,email','password'=>['required','confirmed',Password::min(8)]]);$user=User::create($d);Auth::login($user);$r->session()->regenerate();return redirect()->route('home');}
 public function login(Request $r){$d=$r->validate(['email'=>'required|email','password'=>'required|string']);if(!Auth::attempt($d)){return back()->withErrors(['email'=>'The credentials provided are incorrect.'])->onlyInput('email');}$r->session()->regenerate();return redirect()->intended(route('home'));}
 public function logout(Request $r){Auth::logout();$r->session()->invalidate();$r->session()->regenerateToken();return redirect()->route('home');}
}