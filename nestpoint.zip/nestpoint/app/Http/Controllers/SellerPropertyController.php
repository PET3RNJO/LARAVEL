<?php
namespace App\Http\Controllers;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
class SellerPropertyController extends Controller {
 public function index(Request $r){return view('seller',['properties'=>Property::where('owner_id',$r->user()->id)->latest()->get()]);}
 public function create(){return view('seller-form',['property'=>null]);}
 public function edit(Request $r,Property $property){abort_unless($property->owner_id===$r->user()->id,403);abort_if($property->sale_status!=='available',422);return view('seller-form',compact('property'));}
 private function fields(Request $r):array{return $r->validate(['title'=>'required|string|max:150','location'=>'required|string|max:150','city'=>'required|string|max:80','type'=>['required',Rule::in(['House','Apartment','Commercial'])],'purpose'=>'required|in:Sale,Rent','price'=>'required|integer|min:1','beds'=>'required|integer|min:0|max:100','baths'=>'required|integer|min:0|max:100','area'=>'required|integer|min:1','image'=>'required|url:http,https|max:2000','description'=>'required|string|max:4000','accept_terms'=>'accepted']);}
 public function store(Request $r){$d=$this->fields($r);unset($d['accept_terms']);$d['slug']=Str::slug($d['title']).'-'.Str::lower(Str::random(6));$d['owner_id']=$r->user()->id;$d['review_status']='pending';$d['active']=false;Property::create($d);return redirect()->route('seller.index')->with('success','Property submitted for review. It will not appear publicly until approved.');}
 public function update(Request $r,Property $property){abort_unless($property->owner_id===$r->user()->id,403);abort_if($property->sale_status!=='available',422);$d=$this->fields($r);unset($d['accept_terms']);$d['review_status']='pending';$d['active']=false;$property->update($d);return redirect()->route('seller.index')->with('success','Changes submitted for review.');}
 public function reportSale(Request $r,Property $property){abort_unless($property->owner_id===$r->user()->id,403);abort_unless($property->purpose==='Sale'&&$property->review_status==='approved'&&$property->sale_status==='available',422);$d=$r->validate(['agreed_sale_price'=>'required|integer|min:1','sale_reference'=>'required|string|min:10|max:2000']);$property->update(['sale_status'=>'reported','agreed_sale_price'=>$d['agreed_sale_price'],'sale_reference'=>$d['sale_reference'],'active'=>false]);return back()->with('success','Sale reported. An administrator must verify completion and commission.');}
}