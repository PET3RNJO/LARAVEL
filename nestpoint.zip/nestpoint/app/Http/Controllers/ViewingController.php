<?php
namespace App\Http\Controllers;
use App\Models\Property;
use App\Models\Viewing;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\DB;
class ViewingController extends Controller {
 public function index(Request $r){$viewings=Viewing::with('property')->where('user_id',$r->user()->id)->latest()->get();return view('viewings',compact('viewings'));}
 public function store(Request $r,Property $property){abort_unless($property->active,404);$d=$r->validate(['viewing_date'=>'required|date|after_or_equal:today','viewing_time'=>'required|date_format:H:i','message'=>'nullable|string|max:1000']);$at=\Carbon\Carbon::parse($d['viewing_date'].' '.$d['viewing_time'],'Africa/Lusaka');if($at->isPast()){throw ValidationException::withMessages(['viewing_date'=>'Please choose a future date and time.']);}if($at->format('H:i')<'08:00'||$at->format('H:i')>'17:00'){throw ValidationException::withMessages(['viewing_time'=>'Please select a time between 08:00 and 17:00.']);}$conflict=Viewing::where('property_id',$property->id)->whereDate('viewing_date',$d['viewing_date'])->where('viewing_time',$d['viewing_time'])->whereIn('status',['pending','confirmed'])->exists();if($conflict){throw ValidationException::withMessages(['viewing_time'=>'A viewing is already requested at this time.']);}Viewing::create([...$d,'property_id'=>$property->id,'user_id'=>$r->user()->id,'status'=>'pending']);return redirect()->route('viewings.index')->with('success','Viewing request submitted.');}
 public function cancel(Request $r,Viewing $viewing){abort_unless($viewing->user_id===$r->user()->id,403);if($viewing->status==='pending'){$viewing->update(['status'=>'cancelled']);}return back()->with('success','Viewing request updated.');}
}