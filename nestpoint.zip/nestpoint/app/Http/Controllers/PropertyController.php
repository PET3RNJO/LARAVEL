<?php
namespace App\Http\Controllers;
use App\Models\Property;
use Illuminate\Http\Request;
class PropertyController extends Controller{
 public function index(Request $request){$query=Property::query()->where('active',true);if($search=trim((string)$request->query('search',''))){$query->where(function($q)use($search){$q->where('title','like',"%$search%")->orWhere('location','like',"%$search%")->orWhere('city','like',"%$search%");});}foreach(['purpose','type','city'] as $field){if($value=$request->query($field)){$query->where($field,$value);}}$properties=$query->orderByDesc('featured')->latest()->get()->map(fn($p)=>$p->toArray());return view('home',['properties'=>$properties]);}
 public function show(string $slug){$property=Property::where('slug',$slug)->where('active',true)->firstOrFail()->toArray();return view('property',compact('property'));}
}