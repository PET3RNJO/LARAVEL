<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Property extends Model {
 protected $fillable=['slug','title','location','city','type','purpose','price','beds','baths','area','image','description','featured','active','owner_id','review_status','sale_status','agreed_sale_price','sold_at','commission_rate','commission_amount','commission_status','sale_reference'];
 protected $casts=['featured'=>'boolean','active'=>'boolean'];
 public function owner(){return $this->belongsTo(User::class,'owner_id');}
 public function viewings(){return $this->hasMany(Viewing::class);}
}