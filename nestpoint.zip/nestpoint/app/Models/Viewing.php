<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Viewing extends Model {
 protected $fillable=['user_id','property_id','viewing_date','viewing_time','message','status'];
 protected $casts=['viewing_date'=>'date'];
 public function property(){return $this->belongsTo(Property::class);}
 public function user(){return $this->belongsTo(User::class);}
}