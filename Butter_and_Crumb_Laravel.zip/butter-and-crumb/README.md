# Butter & Crumb — Laravel bakery mini project

A small, finished bakery storefront using Laravel 12, Blade, plain CSS and SQLite. PHP 8.2+ and Composer are required. No Node, npm, Vite, MySQL or XAMPP setup is needed for this app.

## Start on Windows with Laravel Herd (one time)
1. Extract this ZIP first. Open the extracted `butter-and-crumb` folder in VS Code. This is the folder containing `artisan` and `composer.json`, not the parent ZIP folder.
2. Open a PowerShell terminal in that folder and run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\setup.ps1
   ```
   This installs dependencies only when missing, copies `.env` only when missing, creates SQLite only when missing, generates a key only when missing, and applies migrations without resetting existing records.
3. Link this folder through Herd's Sites interface, with site name `butter-and-crumb`. If the Herd command is available, run:
   ```powershell
   herd link butter-and-crumb
   ```
4. Open **http://butter-and-crumb.test**. Keep Herd running. You do not need to repeat setup every time or run `php artisan serve` with Herd.
5. Click **Log in → Create an account** to register your own account. There is no preconfigured demo password.

If your PHP/Composer commands are missing, restart the terminal after installing Herd. Herd should use PHP 8.2 or newer with PDO SQLite enabled. If Herd reports "site not found", make sure it links to the folder containing `artisan`, with its web root directed to `public`.

## Without Herd
Run `bash setup.sh` on Linux/macOS, or the PowerShell setup above on Windows. Then run `php artisan serve` and open the address printed by Laravel (normally http://127.0.0.1:8000). Keep that terminal open while using this mode.

## What is included
- Responsive landing page with three locally bundled, realistic AI-generated bakery photos.
- Three products: Berry Vanilla Cake (K450), Chocolate Dream (K500), Berry Cupcake Box (K180).
- Registration, password hashing, login, logout and protected account pages.
- Session cart: add, update quantities (1–10 each), remove, subtotal and total.
- Checkout with collection date, contact details and optional cake/order note.
- Payment on collection and a clearly labelled demo online payment.
- Saved orders, order confirmation and account-specific order history.
- Basic catering information for baking and cooking services.
- CSRF protection, request validation, authentication throttling, server-calculated totals, and duplicate checkout protection.

## Payment and business limits
This is a local learning/demo shop. The demo payment marks an order `demo_paid` without processing money. Pay-on-collection orders stay `pending_collection`. No card details are collected; no live card, Mobile Money, merchant payout, refund, email or SMS integration is included. Merchant payouts require a payment provider and are outside this small project.

Collection-only ordering; the example business has no real address or operating hours. Add your actual business details before using it with customers. Cakes/cupcakes can be ordered online; cooked catering and custom menus are informational only. There is no admin dashboard, stock control, booking capacity, password reset or delivery integration.

Photographs are AI-generated illustrations of the demo menu, not photos of goods from a real bakery. The prompts describe realistic vanilla berry cake, chocolate ganache cake and a six-cupcake box, with cream linen backgrounds and natural window light. They were generated using the built-in image tool and are bundled in `public/images/`.

## Files and connections
- `routes/web.php`: browser URLs and middleware.
- `app/Http/Controllers/AuthController.php`: account actions.
- `app/Http/Controllers/ShopController.php`: cart, checkout and orders.
- `app/Support/Catalog.php`: three products, integer minor-unit prices and currency formatting. Edit this to change menu/prices.
- `app/Models/Order.php`: persisted orders and item snapshots.
- `database/migrations/`: user and order database structure.
- `resources/views/`: Blade landing page, login, cart, checkout and order screens.
- `public/css/shop.css`: responsive design. No external fonts or CDNs.
- `public/images/`: bundled bakery photos.
- `.env`: your local configuration, created by setup; never share a real production `.env`.
- `database/database.sqlite`: created by setup; stores accounts and orders on your own machine.

Browser → route → controller → model/SQLite where needed → Blade view → browser. The cart stays in the Laravel session. Product prices come from the server. Orders save the product snapshot so later menu changes do not alter old orders.

## Validation
Run `php artisan test` after setup. Feature tests cover storefront, cart operations/limits, account flow, guest checkout redirect, server-side pricing, payment states, duplicate checkout, empty carts and private orders.

## Before real launch
Connect a real payment provider with verified server-side webhooks before marking orders paid. Add actual collection/contact details, menu/allergen policies, fulfilment management, password recovery and production deployment configuration. Use HTTPS and `APP_DEBUG=false` on production.

## Framework
Built on the official Laravel application skeleton (MIT). See `FRAMEWORK-LICENSE.txt`.
