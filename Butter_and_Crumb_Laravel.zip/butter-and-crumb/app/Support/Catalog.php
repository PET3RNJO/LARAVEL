<?php

namespace App\Support;

class Catalog
{
    public static function all(): array
    {
        return [
            1 => ['id' => 1, 'name' => 'Berry Vanilla Cake', 'category' => 'Celebration cake', 'description' => 'Soft vanilla layers, silky buttercream and a generous handful of fresh berries.', 'detail' => 'Whole 8-inch cake · serves 8–10', 'price' => 45000, 'image' => 'berry-cake.jpg', 'allergens' => 'Wheat, eggs and milk'],
            2 => ['id' => 2, 'name' => 'Chocolate Dream', 'category' => 'Celebration cake', 'description' => 'Rich chocolate sponge finished with glossy chocolate ganache. A little slice of joy.', 'detail' => 'Whole 8-inch cake · serves 8–10', 'price' => 50000, 'image' => 'chocolate-cake.jpg', 'allergens' => 'Wheat, eggs, milk and soy'],
            3 => ['id' => 3, 'name' => 'Berry Cupcake Box', 'category' => 'Freshly baked treats', 'description' => 'Six fluffy vanilla cupcakes with buttercream swirls and fresh berries. Made for sharing.', 'detail' => 'Box of 6 cupcakes', 'price' => 18000, 'image' => 'cupcakes.jpg', 'allergens' => 'Wheat, eggs and milk'],
        ];
    }

    public static function find(int $id): array
    {
        return self::all()[$id] ?? abort(404);
    }

    public static function money(int $cents): string
    {
        return 'K '.number_format($cents / 100, 2);
    }
}
