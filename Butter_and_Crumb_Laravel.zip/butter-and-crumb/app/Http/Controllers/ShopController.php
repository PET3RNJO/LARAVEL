<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ShopController extends Controller
{
    private function basket(Request $request): array
    {
        $items = [];
        $total = 0;
        foreach ($request->session()->get('cart', []) as $id => $quantity) {
            $product = Catalog::find((int) $id);
            $product['quantity'] = (int) $quantity;
            $product['subtotal'] = $product['price'] * $quantity;
            $items[] = $product;
            $total += $product['subtotal'];
        }

        return ['items' => $items, 'total' => $total];
    }

    public function home()
    {
        return view('home', ['products' => Catalog::all()]);
    }

    public function cart(Request $request)
    {
        return view('cart', $this->basket($request));
    }

    public function add(Request $request, int $product)
    {
        Catalog::find($product);
        $data = $request->validate(['quantity' => 'sometimes|required|integer|min:1|max:10']);
        $cart = $request->session()->get('cart', []);
        $quantity = ($cart[$product] ?? 0) + ($data['quantity'] ?? 1);
        if ($quantity > 10) {
            return back()->withErrors(['cart' => 'You can order up to 10 of each item.']);
        }
        $cart[$product] = $quantity;
        $request->session()->put('cart', $cart);

        return back()->with('success', Catalog::find($product)['name'].' added to your cart.');
    }

    public function update(Request $request, int $product)
    {
        Catalog::find($product);
        $data = $request->validate(['quantity' => 'required|integer|min:1|max:10']);
        $cart = $request->session()->get('cart', []);
        abort_unless(isset($cart[$product]), 404);
        $cart[$product] = (int) $data['quantity'];
        $request->session()->put('cart', $cart);

        return redirect()->route('cart')->with('success', 'Cart updated.');
    }

    public function remove(Request $request, int $product)
    {
        Catalog::find($product);
        $cart = $request->session()->get('cart', []);
        unset($cart[$product]);
        $request->session()->put('cart', $cart);

        return redirect()->route('cart')->with('success', 'Item removed.');
    }

    public function checkout(Request $request)
    {
        $basket = $this->basket($request);
        if (! $basket['items']) {
            return redirect()->route('cart')->withErrors(['cart' => 'Add something to your cart first.']);
        }
        if (! $request->session()->has('checkout_token')) {
            $request->session()->put('checkout_token', (string) Str::uuid());
        }

        return view('checkout', $basket + ['token' => $request->session()->get('checkout_token')]);
    }

    public function placeOrder(Request $request)
    {
        $data = $request->validate([
            'checkout_token' => 'required|uuid', 'customer_name' => 'required|string|max:100',
            'phone' => ['required', 'string', 'max:30', 'regex:/^[+0-9 ()-]{7,30}$/'],
            'collection_date' => 'required|date_format:Y-m-d|after:today|before_or_equal:'.now()->addDays(90)->format('Y-m-d'),
            'notes' => 'nullable|string|max:500', 'payment_method' => ['required', Rule::in(['collection', 'demo'])], 'terms' => 'accepted',
        ]);
        $existing = Order::where('checkout_token', $data['checkout_token'])->where('user_id', $request->user()->id)->first();
        if ($existing) {
            return redirect()->route('orders.show', $existing);
        }
        abort_unless(hash_equals((string) $request->session()->get('checkout_token', ''), $data['checkout_token']), 419);
        $basket = $this->basket($request);
        if (! $basket['items']) {
            return redirect()->route('cart')->withErrors(['cart' => 'Your cart is empty.']);
        }
        // Prices and totals come only from the server catalog, never from form inputs.
        $order = Order::firstOrCreate(['checkout_token' => $data['checkout_token']], [
            'user_id' => $request->user()->id, 'customer_name' => $data['customer_name'], 'phone' => $data['phone'],
            'collection_date' => $data['collection_date'], 'notes' => $data['notes'] ?? null, 'items' => $basket['items'], 'total' => $basket['total'],
            'payment_method' => $data['payment_method'], 'payment_status' => $data['payment_method'] === 'demo' ? 'demo_paid' : 'pending_collection',
        ]);
        abort_unless($order->user_id === $request->user()->id, 403);
        $request->session()->forget(['cart', 'checkout_token']);

        return redirect()->route('orders.show', $order);
    }

    public function orders(Request $request)
    {
        return view('orders', ['orders' => Order::where('user_id', $request->user()->id)->latest()->paginate(10)]);
    }

    public function confirmation(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);

        return view('confirmation',compact('order'));
    }
}
