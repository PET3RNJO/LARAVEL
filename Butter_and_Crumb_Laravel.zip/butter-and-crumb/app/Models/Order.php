<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['user_id', 'checkout_token', 'customer_name', 'phone', 'collection_date', 'notes', 'items', 'total', 'payment_method', 'payment_status'];

    protected function casts(): array
    {
        return ['items' => 'array', 'collection_date' => 'date', 'total' => 'integer'];
    }

    public function reference(): string
    {
        return 'BC-'.str_pad((string) $this->id, 5, '0', STR_PAD_LEFT);
    }
}
