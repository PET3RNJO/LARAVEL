<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ShopController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ShopController::class, 'home'])->name('home');
Route::get('/cart', [ShopController::class, 'cart'])->name('cart');
Route::post('/cart/{product}', [ShopController::class, 'add'])->name('cart.add');
Route::patch('/cart/{product}', [ShopController::class, 'update'])->name('cart.update');
Route::delete('/cart/{product}', [ShopController::class, 'remove'])->name('cart.remove');
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:10,1');
});
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/checkout', [ShopController::class, 'checkout'])->name('checkout');
    Route::post('/checkout', [ShopController::class, 'placeOrder'])->middleware('throttle:10,1')->name('checkout.store');
    Route::get('/orders', [ShopController::class, 'orders'])->name('orders');
    Route::get('/orders/{order}', [ShopController::class, 'confirmation'])->name('orders.show');
});
