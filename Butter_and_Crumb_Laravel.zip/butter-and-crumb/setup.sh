#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f vendor/autoload.php ]; then composer install --no-interaction --prefer-dist; fi
if [ ! -f .env ]; then cp .env.example .env; fi
if [ ! -f database/database.sqlite ]; then touch database/database.sqlite; fi
php -r '$s=file_get_contents(".env"); exit(preg_match("/^APP_KEY=.+$/m",$s)?0:1);' || php artisan key:generate
php artisan migrate --force
php artisan optimize:clear
printf 'Ready. Link this folder in Herd or run php artisan serve.\n'
