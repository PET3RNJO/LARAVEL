<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->uuid('checkout_token')->unique();
            $table->string('customer_name', 100);
            $table->string('phone', 30);
            $table->date('collection_date');
            $table->text('notes')->nullable();
            $table->json('items');
            $table->unsignedInteger('total');
            $table->string('payment_method');
            $table->string('payment_status');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
