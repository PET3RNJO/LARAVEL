<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Tests\TestCase;

class ShopTest extends TestCase
{
    use RefreshDatabase;

    private function checkoutData(string $token, string $method = 'collection'): array
    {
        return ['checkout_token' => $token, 'customer_name' => 'Peter', 'phone' => '+260971234567', 'collection_date' => now()->addDay()->format('Y-m-d'), 'payment_method' => $method, 'terms' => '1'];
    }

    public function test_storefront_and_empty_cart_render(): void
    {
        $this->get('/')->assertOk()->assertSee('Berry Vanilla Cake')->assertSee('Chocolate Dream');
        $this->get('/cart')->assertOk()->assertSee('Your cart is empty');
    }

    public function test_cart_add_update_remove_and_limits(): void
    {
        $this->post('/cart/1', ['quantity' => 2])->assertRedirect()->assertSessionHas('cart.1', 2);
        $this->patch('/cart/1', ['quantity' => 3])->assertRedirect('/cart')->assertSessionHas('cart.1', 3);
        $this->post('/cart/1', ['quantity' => 8])->assertSessionHasErrors('cart')->assertSessionHas('cart.1', 3);
        $this->patch('/cart/1', ['quantity' => 0])->assertSessionHasErrors('quantity');
        $this->post('/cart/999')->assertNotFound();
        $this->delete('/cart/1')->assertRedirect('/cart')->assertSessionHas('cart', []);
    }

    public function test_registration_login_logout_and_cart_preservation(): void
    {
        $this->withSession(['cart' => [1 => 1]])->post('/register', ['name' => 'Peter', 'email' => 'peter@example.com', 'password' => 'CakeTime123', 'password_confirmation' => 'CakeTime123'])->assertRedirect('/')->assertSessionHas('cart.1', 1);
        $user = User::where('email', 'peter@example.com')->firstOrFail();
        $this->assertAuthenticatedAs($user);
        $this->assertTrue(Hash::check('CakeTime123', $user->password));
        $this->post('/logout')->assertRedirect('/');
        $this->assertGuest();
        $this->post('/login', ['email' => 'peter@example.com', 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->post('/login', ['email' => 'peter@example.com', 'password' => 'CakeTime123'])->assertRedirect('/');
        $this->assertAuthenticatedAs($user);
    }

    public function test_guest_must_log_in_to_checkout(): void
    {
        $this->withSession(['cart' => [1 => 1]])->get('/checkout')->assertRedirect('/login');
    }

    public function test_checkout_uses_server_prices_and_saves_collection_order(): void
    {
        $user = User::factory()->create();
        $token = (string) Str::uuid();
        $this->actingAs($user)->withSession(['cart' => [1 => 2, 3 => 1], 'checkout_token' => $token]);
        $this->get('/checkout')->assertOk()->assertSee('K 1,080.00');
        $this->post('/checkout', $this->checkoutData($token) + ['total' => 1, 'price' => 1])->assertRedirect()->assertSessionMissing('cart');
        $order = Order::firstOrFail();
        $this->assertSame(108000, $order->total);
        $this->assertSame('pending_collection', $order->payment_status);
        $this->get('/orders/'.$order->id)->assertOk()->assertSee('Due on collection');
        $this->get('/orders')->assertOk()->assertSee($order->reference());
    }

    public function test_demo_payment_and_duplicate_submit_make_one_order(): void
    {
        $user = User::factory()->create();
        $token = (string) Str::uuid();
        $this->actingAs($user)->withSession(['cart' => [2 => 1], 'checkout_token' => $token]);
        $data = $this->checkoutData($token, 'demo');
        $this->post('/checkout', $data)->assertRedirect();
        $this->post('/checkout', $data)->assertRedirect();
        $this->assertDatabaseCount('orders', 1);
        $this->assertDatabaseHas('orders', ['payment_status' => 'demo_paid', 'total' => 50000]);
    }

    public function test_checkout_validation_and_empty_cart(): void
    {
        $user = User::factory()->create();
        $token = (string) Str::uuid();
        $this->actingAs($user);
        $this->get('/checkout')->assertRedirect('/cart');
        $this->withSession(['cart' => [1 => 1], 'checkout_token' => $token])->post('/checkout', array_merge($this->checkoutData($token), ['collection_date' => now()->format('Y-m-d'), 'payment_method' => 'card']))->assertSessionHasErrors(['collection_date', 'payment_method']);
        $this->assertDatabaseCount('orders', 0);
    }

    public function test_invalid_token_and_other_users_orders_are_denied(): void
    {
        $owner = User::factory()->create();
        $token = (string) Str::uuid();
        $this->actingAs($owner)->withSession(['cart' => [1 => 1], 'checkout_token' => $token]);
        $this->post('/checkout', $this->checkoutData((string) Str::uuid()))->assertStatus(419);
        $this->post('/checkout', $this->checkoutData($token))->assertRedirect();
        $other = User::factory()->create();
        $this->actingAs($other)->get('/orders/'.Order::firstOrFail()->id)->assertForbidden();
        $this->get('/orders')->assertDontSee(Order::firstOrFail()->reference());
    }
}
