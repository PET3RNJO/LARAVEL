$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
function Run-Checked {
 param([string]$Program, [string[]]$Arguments)
 & $Program @Arguments
 if ($LASTEXITCODE -ne 0) { throw "$Program failed. Check the message above." }
}
Write-Host "Setting up Butter & Crumb..." -ForegroundColor Green
if (-not (Get-Command php -ErrorAction SilentlyContinue)) { throw "PHP is missing. Open a new terminal after installing Laravel Herd." }
if (-not (Test-Path "vendor/autoload.php")) { Run-Checked -Program "composer" -Arguments @("install", "--no-interaction", "--prefer-dist") }
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
if (-not (Test-Path "database/database.sqlite")) { New-Item "database/database.sqlite" -ItemType File | Out-Null }
$keyLine = Get-Content ".env" | Where-Object { $_ -match '^APP_KEY=.+$' }
if (-not $keyLine) { Run-Checked -Program "php" -Arguments @("artisan", "key:generate") }
Run-Checked -Program "php" -Arguments @("artisan", "migrate", "--force")
Run-Checked -Program "php" -Arguments @("artisan", "optimize:clear")
Write-Host "Ready! In Herd add this folder as a site, or run: herd link butter-and-crumb" -ForegroundColor Green
Write-Host "Then open http://butter-and-crumb.test whenever Herd is running."
