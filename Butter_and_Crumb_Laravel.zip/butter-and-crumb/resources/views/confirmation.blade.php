
@extends('layout')
@section('title','Order confirmed · Butter & Crumb')
@section('content')
<section class="section confirmation"><div class="success-mark">✓</div><p class="eyebrow">THANK YOU, {{ $order->customer_name }}</p><h1>A sweet moment<br>is on its way.</h1><p>Your demo order has been saved. Here are the details.</p><div class="receipt"><div class="summary-row"><strong>{{ $order->reference() }}</strong><span>{{ $order->created_at->format('d M Y') }}</span></div><div class="summary-row"><span>Collection date</span><strong>{{ $order->collection_date->format('d M Y') }}</strong></div><div class="summary-row"><span>Payment</span><strong>{{ $order->payment_method==='demo'?'Demo paid — no charge':'Due on collection' }}</strong></div>
@foreach($order->items as $item)<div class="summary-row"><span>{{ $item['name'] }} × {{ $item['quantity'] }}</span><span>{{ \App\Support\Catalog::money($item['subtotal']) }}</span></div>
@endforeach<div class="summary-row total"><strong>Total</strong><strong>{{ \App\Support\Catalog::money($order->total) }}</strong></div>
@if($order->notes)<p><strong>Your note:</strong> {{ $order->notes }}</p>
@endif</div><p class="muted">No real payment was processed. No email or SMS is sent by this demo.</p><div class="actions"><a class="button" href="{{ route('home') }}#shop">Back to our bakes ↗</a><a class="text-link" href="{{ route('orders') }}">View my orders</a></div></section>
@endsection
