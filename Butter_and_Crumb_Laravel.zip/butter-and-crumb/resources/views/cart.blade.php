
@extends('layout')
@section('title','Your cart · Butter & Crumb')
@section('content')
<section class="section page"><p class="eyebrow">A LITTLE BOX OF JOY</p><h1>Your cart.</h1>
@if(!$items)<div class="empty"><span>✳</span><h2>Room for something delicious.</h2><p>Your cart is empty. Let’s fix that with a freshly baked favourite.</p><a class="button" href="{{ route('home') }}#shop">Explore our bakes ↗</a></div>
@else<div class="shopping-layout"><div class="cart-items">
@foreach($items as $item)<article class="cart-item"><img src="{{ asset('images/'.$item['image']) }}" alt="{{ $item['name'] }}"><div><h3>{{ $item['name'] }}</h3><p>{{ $item['detail'] }}</p><small>{{ \App\Support\Catalog::money($item['price']) }} each</small><div class="quantity-actions"><form action="{{ route('cart.update',$item['id']) }}" method="post">
@csrf 
@method('PATCH')<label class="sr-only" for="qty-{{ $item['id'] }}">Quantity for {{ $item['name'] }}</label><input id="qty-{{ $item['id'] }}" name="quantity" type="number" value="{{ $item['quantity'] }}" min="1" max="10" required><button class="text-link">Update</button></form><form action="{{ route('cart.remove',$item['id']) }}" method="post">
@csrf 
@method('DELETE')<button class="text-link remove">Remove</button></form></div></div><strong>{{ \App\Support\Catalog::money($item['subtotal']) }}</strong></article>
@endforeach<a class="text-link" href="{{ route('home') }}#shop">← Continue shopping</a></div><aside class="summary"><p class="eyebrow">THE SWEET DETAILS</p><h2>Order summary</h2><div class="summary-row"><span>Subtotal</span><span>{{ \App\Support\Catalog::money($total) }}</span></div><div class="summary-row"><span>Collection</span><span>Free</span></div><div class="summary-row total"><strong>Total</strong><strong>{{ \App\Support\Catalog::money($total) }}</strong></div><a class="button full" href="{{ route('checkout') }}">Continue to checkout ↗</a><p>Made to order. Choose your collection date at checkout.</p>
@guest<small>You’ll be asked to log in or create an account.</small>
@endguest</aside></div>
@endif</section>
@endsection
