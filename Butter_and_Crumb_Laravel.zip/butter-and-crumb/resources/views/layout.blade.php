<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="Butter & Crumb — a small artisan bakery. Shop cakes and fresh treats, and explore our catering services."><title>
@yield('title','Butter & Crumb · Baked with love')</title><link rel="stylesheet" href="{{ asset('css/shop.css') }}"></head>
<body><div class="announcement">A little sweetness, made from scratch. <span>Order today · Collect from tomorrow</span></div>
<header class="header"><a class="brand" href="{{ route('home') }}"><span class="brand-icon">b.</span><span>butter & crumb<small>BAKERY & KITCHEN</small></span></a>
<nav aria-label="Main navigation"><a href="{{ route('home') }}#shop">Our bakes</a><a href="{{ route('home') }}#services">Catering</a>
@auth<a href="{{ route('orders') }}">My orders</a><form action="{{ route('logout') }}" method="post">
@csrf<button class="nav-link">Sign out</button></form>
@else<a href="{{ route('login') }}">Log in</a>
@endauth<a class="cart-link" href="{{ route('cart') }}">Cart <span>{{ array_sum(session('cart',[])) }}</span></a></nav></header>
<main>
@if(session('success'))<div class="notice" role="status">{{ session('success') }}</div>
@endif
@if($errors->any())<div class="notice error" role="alert"><strong>Please check the following:</strong><ul>
@foreach($errors->all() as $error)<li>{{ $error }}</li>
@endforeach</ul></div>
@endif
@yield('content')</main>
<footer><a class="brand footer-brand" href="{{ route('home') }}">butter & crumb</a><p>Good food. Small moments. Sweeter memories.</p><div class="footer-bottom"><span>© {{ date('Y') }} Butter & Crumb</span><span>Local demo shop · ZMW prices · Collection only</span></div></footer></body></html>
