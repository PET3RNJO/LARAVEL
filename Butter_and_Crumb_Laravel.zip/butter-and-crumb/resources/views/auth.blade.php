
@extends('layout')
@section('title',($mode==='register'?'Create an account':'Welcome back').' · Butter & Crumb')
@section('content')
<section class="auth-shell"><div class="auth-photo"><img src="{{ asset('images/chocolate-cake.jpg') }}" alt="Chocolate cake with glossy ganache"><div><p class="eyebrow">A LITTLE TREAT AWAITS</p><h2>Good to have<br>you here.</h2></div></div><div class="auth-form"><p class="eyebrow">BUTTER & CRUMB CLUB</p><h1>{{ $mode==='register'?'Make yourself at home.':'Welcome back.' }}</h1><p>{{ $mode==='register'?'Create an account to order your favourite bakes.':'Log in to checkout and see your orders.' }}</p><form action="{{ url($mode) }}" method="post">
@csrf
@if($mode==='register')<label for="name">Your name</label><input id="name" name="name" value="{{ old('name') }}" maxlength="100" autocomplete="name" required>
@endif
<label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email') }}" maxlength="255" autocomplete="email" required>
<label for="password">Password 
@if($mode==='register')<small>(at least 8 characters)</small>
@endif</label><input id="password" type="password" name="password" minlength="{{ $mode==='register'?8:1 }}" autocomplete="{{ $mode==='register'?'new-password':'current-password' }}" required>
@if($mode==='register')<label for="password_confirmation">Confirm password</label><input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" required>
@endif
<button class="button full">{{ $mode==='register'?'Create account':'Log in' }} ↗</button></form><p class="auth-switch">{{ $mode==='register'?'Already have an account?':'New around here?' }} <a href="{{ route($mode==='register'?'login':'register') }}">{{ $mode==='register'?'Log in':'Create an account' }}</a></p></div></section>
@endsection
