
@extends('layout')
@section('title','My orders · Butter & Crumb')
@section('content')
<section class="section page"><p class="eyebrow">YOUR SWEET MOMENTS</p><h1>My orders.</h1>
@forelse($orders as $order)<a class="order-card" href="{{ route('orders.show',$order) }}"><div><h3>{{ $order->reference() }}</h3><p>Collection: {{ $order->collection_date->format('d M Y') }}</p><small>{{ $order->payment_method==='demo'?'Demo paid — no charge':'Payment due on collection' }}</small></div><strong>{{ \App\Support\Catalog::money($order->total) }} <span>↗</span></strong></a>
@empty<div class="empty"><h2>Your first sweet moment awaits.</h2><p>You haven’t placed an order yet.</p><a class="button" href="{{ route('home') }}#shop">Shop our bakes ↗</a></div>
@endforelse
@if($orders->hasPages())<div class="pagination">
@if($orders->previousPageUrl())<a class="text-link" href="{{ $orders->previousPageUrl() }}">← Previous</a>
@endif<span>Page {{ $orders->currentPage() }} of {{ $orders->lastPage() }}</span>
@if($orders->nextPageUrl())<a class="text-link" href="{{ $orders->nextPageUrl() }}">Next →</a>
@endif</div>
@endif</section>
@endsection
