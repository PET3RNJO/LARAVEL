
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Book Appointment | Blade & Brush</title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <style>
        .booking-page {
            min-height: 100vh;
            background: #111;
            padding: 70px 20px;
        }

        .booking-container {
            max-width: 750px;
            margin: auto;
        }

        .booking-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .booking-header h1 {
            font-size: 45px;
            color: #d4af37;
        }

        .booking-header p {
            color: #aaa;
        }

        .booking-form {
            background: #1d1d1d;
            border: 1px solid #383838;
            padding: 35px;
            border-radius: 12px;
        }

        .form-group {
            margin-bottom: 22px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .form-group select,
        .form-group input,
        .form-group textarea {
            width: 100%;
            background: #292929;
            color: #fff;
            border: 1px solid #555;
            padding: 14px;
            border-radius: 5px;
            font: inherit;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: 2px solid #d4af37;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .booking-note {
            color: #aaa;
            font-size: 13px;
            margin-bottom: 22px;
        }

        .booking-submit {
    display: block;
    width: 100%;
    border: 0;
    cursor: pointer;
    text-align: center;
}

        .back-home {
            display: inline-block;
            color: #d4af37;
            margin-top: 25px;
        }

        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }

            .booking-form {
                padding: 22px;
            }
        }
    </style>
</head>

<body>
    <main class="booking-page">
        <div class="booking-container">

            <div class="booking-header">
                <p class="eyebrow">BLADE & BRUSH</p>
                <h1>Book Your Appointment</h1>
                <p>Select your preferred service, barber, date and time.</p>
            </div>

            
<form class="booking-form"
      method="POST"
      action="{{ route('booking.store') }}">
    @csrf

    @if(session('success'))
        <div class="booking-success" role="status">
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="booking-errors" role="alert">
            <strong>Please correct the following:</strong>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


                
<div class="form-group">
    <label for="service_id">Select Service</label>

    <select id="service_id" name="service_id" required>
        <option value="">Choose a service</option>

        @foreach($services as $service)
            <option value="{{ $service->id }}"
                @selected(old('service_id') == $service->id)>
                {{ $service->name }} —
                K{{ number_format($service->price, 2) }}
                ({{ $service->duration_minutes }} min)
            </option>
        @endforeach
    </select>
</div>

<div class="form-group">
    <label for="barber_id">Preferred Barber</label>

    <select id="barber_id" name="barber_id" required>
        <option value="">Choose your barber</option>

        @foreach($barbers as $barber)
            <option value="{{ $barber->id }}"
                @selected(old('barber_id') == $barber->id)>
                {{ $barber->name }} — {{ $barber->specialty }}
            </option>
        @endforeach
    </select>
</div>


                
<div class="form-row">

    <div class="form-group">
        <label for="appointment_date">Appointment Date</label>

        <input
            type="date"
            id="appointment_date"
            name="appointment_date"
            min="{{ now('Africa/Lusaka')->format('Y-m-d') }}"
            value="{{ old('appointment_date') }}"
            required
        >
    </div>

    <div class="form-group">
        <label for="appointment_time">Preferred Time</label>

        <input
            type="time"
            id="appointment_time"
            name="appointment_time"
            min="08:00"
            max="18:00"
            step="300"
            value="{{ old('appointment_time') }}"
            required
        >
    </div>

</div>


                   

                
<div class="form-group">
    <label for="notes">Additional Notes (Optional)</label>

    <textarea
        id="notes"
        name="notes"
        rows="4"
        maxlength="1000"
        placeholder="Any special requests?"
    >{{ old('notes') }}</textarea>
</div>

@auth
    <button class="btn booking-submit" type="submit">
        Confirm Appointment
    </button>
@else
    <a href="{{ route('login') }}" class="btn booking-submit">
        Login to Book an Appointment
    </a>
@endauth

                </div>



            </form>

            <a href="{{ url('/') }}" class="back-home">
                ← Back to Homepage
            </a>

        </div>
    </main>
</body>
</html>
