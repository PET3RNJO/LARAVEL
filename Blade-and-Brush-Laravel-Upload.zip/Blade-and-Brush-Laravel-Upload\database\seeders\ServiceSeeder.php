<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            [
                'name' => 'Classic Haircut',
                'description' => 'Professional haircut with expert finishing and styling.',
                'price' => 150.00,
                'duration_minutes' => 45,
                'is_active' => true,
            ],
            [
                'name' => 'Skin Fade',
                'description' => 'Sharp fades, clean transitions and precise detailing.',
                'price' => 180.00,
                'duration_minutes' => 50,
                'is_active' => true,
            ],
            [
                'name' => 'Beard Grooming',
                'description' => 'Expert beard shaping, trimming and finishing.',
                'price' => 80.00,
                'duration_minutes' => 25,
                'is_active' => true,
            ],
            [
                'name' => 'Full Grooming',
                'description' => 'Complete haircut, beard treatment and styling.',
                'price' => 250.00,
                'duration_minutes' => 75,
                'is_active' => true,
            ],
        ];

        foreach ($services as $service) {
            Service::updateOrCreate(
                ['name' => $service['name']],
                $service
            );
        }
    }
}
