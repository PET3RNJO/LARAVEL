
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings | Blade & Brush</title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <style>
        body {
            background: #101010;
            color: #f6f0e5;
        }

        .bookings-page {
            max-width: 950px;
            width: 90%;
            margin: 65px auto;
        }

        .page-header {
            margin-bottom: 35px;
        }

        .page-header h1 {
            color: #d4af37;
            font-size: 44px;
            margin-bottom: 10px;
        }

        .page-header p {
            color: #aaa;
        }

        .booking-card {
            background: #1d1d1d;
            border: 1px solid #383838;
            border-radius: 12px;
            padding: 26px;
            margin-bottom: 20px;
        }

        .booking-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 20px;
        }

        .booking-top h2 {
            font-size: 25px;
        }

        .status {
            padding: 6px 12px;
            border-radius: 20px;
            background: #363636;
            color: white;
            font-size: 12px;
            font-weight: bold;
            text-transform: capitalize;
        }

        .status-pending {
            background: #55451c;
            color: #f4d77a;
        }

        .status-confirmed {
            background: #174835;
            color: #a7efd0;
        }

        .status-completed {
            background: #253d57;
            color: #b9d7ff;
        }

        .status-cancelled {
            background: #4a2727;
            color: #ffaaaa;
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .booking-details small {
            display: block;
            color: #aaa;
            margin-bottom: 5px;
        }

        .booking-details strong {
            display: block;
        }

        .booking-actions {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #383838;
        }

        .cancel-button {
            background: transparent;
            border: 1px solid #db7777;
            color: #ffaaaa;
            padding: 12px 18px;
            cursor: pointer;
            font: inherit;
        }

        .cancel-button:hover {
            background: #432020;
        }

        .message {
            background: #173b2a;
            color: #baf5d1;
            padding: 16px;
            margin-bottom: 20px;
            border-radius: 6px;
        }

        .error-message {
            background: #492222;
            color: #ffd0d0;
        }

        .empty-state {
            padding: 50px 25px;
            background: #1d1d1d;
            text-align: center;
            border-radius: 12px;
        }

        .empty-state p {
            color: #aaa;
            margin: 15px 0 25px;
        }

        .page-links {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .pagination {
            margin-top: 25px;
        }

        @media (max-width: 600px) {
            .booking-details {
                grid-template-columns: 1fr;
            }

            .booking-top {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <main class="bookings-page">
        <header class="page-header">
            <p class="eyebrow">BLADE & BRUSH</p>
            <h1>My Appointments</h1>
            <p>Welcome, {{ auth()->user()->name }}.</p>
            <p>Review and manage your grooming appointments.</p>
        </header>

        @if(session('success'))
            <div class="message" role="status">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="message error-message" role="alert">
                {{ $errors->first() }}
            </div>
        @endif

        @forelse($appointments as $appointment)
            @php
                $start = \Carbon\CarbonImmutable::parse(
                    $appointment->appointment_date->format('Y-m-d')
                    . ' ' . $appointment->appointment_time,
                    'Africa/Lusaka'
                );

                $canCancel = in_array(
                    $appointment->status,
                    ['pending', 'confirmed']
                ) && $start->isFuture();
            @endphp

            <article class="booking-card">
                <div class="booking-top">
                    <h2>{{ $appointment->service->name }}</h2>

                    <span class="status status-{{ $appointment->status }}">
                        {{ ucfirst($appointment->status) }}
                    </span>
                </div>

                <div class="booking-details">
                    <div>
                        <small>Booking Reference</small>
                        <strong>#{{ $appointment->id }}</strong>
                    </div>

                    <div>
                        <small>Barber</small>
                        <strong>{{ $appointment->barber->name }}</strong>
                    </div>

                    <div>
                        <small>Appointment Date</small>
                        <strong>{{ $start->format('d M Y') }}</strong>
                    </div>

                    <div>
                        <small>Appointment Time</small>
                        <strong>{{ $start->format('h:i A') }}</strong>
                    </div>

                    <div>
                        <small>Duration</small>
                        <strong>
                            {{ $appointment->service->duration_minutes }}
                            minutes
                        </strong>
                    </div>

                    <div>
                        <small>Service Price</small>
                        <strong>
                            K{{ number_format($appointment->service->price, 2) }}
                        </strong>
                    </div>
                </div>

                @if($appointment->notes)
                    <div class="booking-actions">
                        <small>Additional Notes</small>
                        <p>{{ $appointment->notes }}</p>
                    </div>
                @endif

                @if($canCancel)
                    <div class="booking-actions">
                        <form
                            method="POST"
                            action="{{ route('bookings.cancel', $appointment) }}"
                            onsubmit="return confirm('Cancel this appointment?')"
                        >
                            @csrf
                            @method('PATCH')

                            <button type="submit" class="cancel-button">
                                Cancel Appointment
                            </button>
                        </form>
                    </div>
                @endif
            </article>
        @empty
            <div class="empty-state">
                <h2>No appointments yet</h2>
                <p>You haven't booked a grooming session.</p>

                <a class="btn" href="{{ route('booking.create') }}">
                    Book Your First Appointment
                </a>
            </div>
        @endforelse

        <div class="pagination">
            {{ $appointments->links() }}
        </div>

        <div class="page-links">
            <a class="btn" href="{{ route('booking.create') }}">
                Book Another Appointment
            </a>

            <a class="btn btn-outline" href="{{ url('/') }}">
                Back to Homepage
            </a>
        </div>
    </main>
</body>
</html>
