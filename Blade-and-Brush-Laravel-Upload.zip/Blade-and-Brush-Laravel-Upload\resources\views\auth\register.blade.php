
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | Blade & Brush</title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <style>
        .auth-page {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 50px 20px;
            background: #101010;
        }

        .auth-card {
            width: 100%;
            max-width: 470px;
            padding: 40px;
            background: #1c1c1c;
            border: 1px solid #383838;
            border-radius: 12px;
        }

        .auth-card h1 {
            color: #d4af37;
            font-size: 38px;
            text-align: center;
            margin-bottom: 12px;
        }

        .auth-subtitle {
            color: #aaa;
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-group {
            margin-bottom: 20px;
        }

        .auth-group label {
            display: block;
            margin-bottom: 7px;
            font-weight: 600;
        }

        .auth-group input {
            width: 100%;
            padding: 13px;
            border: 1px solid #555;
            border-radius: 5px;
            background: #292929;
            color: white;
            font: inherit;
        }

        .auth-group input:focus {
            outline: 2px solid #d4af37;
        }

        .auth-error {
            color: #ff9090;
            font-size: 13px;
            margin-top: 6px;
        }

        .auth-submit {
            width: 100%;
            cursor: pointer;
        }

        .auth-footer {
            text-align: center;
            margin-top: 25px;
            color: #aaa;
        }

        .auth-footer a {
            color: #d4af37;
        }

        @media (max-width: 500px) {
            .auth-card {
                padding: 25px;
            }
        }
    </style>
</head>

<body>
    <main class="auth-page">
        <div class="auth-card">
            <h1>JOIN BLADE & BRUSH</h1>

            <p class="auth-subtitle">
                Create your account to book appointments.
            </p>

            <form method="POST" action="{{ route('register.store') }}">
                @csrf

                <div class="auth-group">
                    <label for="name">Full Name</label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="{{ old('name') }}"
                        required
                        autocomplete="name"
                    >

                    @error('name')
                        <p class="auth-error">{{ $message }}</p>
                    @enderror
                </div>

                <div class="auth-group">
                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="{{ old('email') }}"
                        required
                        autocomplete="email"
                    >

                    @error('email')
                        <p class="auth-error">{{ $message }}</p>
                    @enderror
                </div>

                <div class="auth-group">
                    <label for="password">Password</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        minlength="8"
                        autocomplete="new-password"
                    >

                    @error('password')
                        <p class="auth-error">{{ $message }}</p>
                    @enderror
                </div>

                <div class="auth-group">
                    <label for="password_confirmation">
                        Confirm Password
                    </label>

                    <input
                        type="password"
                        id="password_confirmation"
                        name="password_confirmation"
                        required
                        minlength="8"
                        autocomplete="new-password"
                    >
                </div>

                <button type="submit" class="btn auth-submit">
                    Create Account
                </button>
            </form>

            <p class="auth-footer">
                Already have an account?
                <a href="{{ route('login') }}">Sign In</a>
            </p>

            <p class="auth-footer">
                <a href="{{ url('/') }}">← Back to Homepage</a>
            </p>
        </div>
    </main>
</body>
</html>
