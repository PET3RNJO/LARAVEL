
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('appointments', function (Blueprint $table) {
            $table->id();

            // Customer making the appointment
            $table->foreignId('user_id')
                ->constrained('users')
                ->restrictOnDelete();

            // Barber assigned to the appointment
            $table->foreignId('barber_id')
                ->constrained('barbers')
                ->restrictOnDelete();

            // Service selected by the customer
            $table->foreignId('service_id')
                ->constrained('services')
                ->restrictOnDelete();

            // Appointment schedule
            $table->date('appointment_date');
            $table->time('appointment_time');

            // Current booking status
            $table->enum('status', [
                'pending',
                'confirmed',
                'completed',
                'cancelled'
            ])->default('pending');

            // Optional customer instructions
            $table->text('notes')->nullable();

            $table->timestamps();

            // Improves barber schedule searches
            $table->index(
                ['barber_id', 'appointment_date', 'appointment_time'],
                'appointments_barber_schedule_index'
            );
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('appointments');
    }
};
