
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Blade & Brush</title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <style>
        .auth-page {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
            background: #101010;
        }

        .auth-card {
            width: 100%;
            max-width: 470px;
            padding: 40px;
            background: #1c1c1c;
            border: 1px solid #383838;
            border-radius: 12px;
        }

        .auth-card h1 {
            color: #d4af37;
            font-size: 40px;
            text-align: center;
            margin-bottom: 12px;
        }

        .auth-subtitle {
            color: #aaa;
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-group {
            margin-bottom: 22px;
        }

        .auth-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .auth-group input {
            width: 100%;
            background: #292929;
            border: 1px solid #555;
            color: #fff;
            padding: 14px;
            border-radius: 5px;
            font: inherit;
        }

        .auth-group input:focus {
            outline: 2px solid #d4af37;
        }

        .auth-error {
            color: #ff9090;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .auth-submit {
            width: 100%;
            cursor: pointer;
            margin-top: 8px;
        }

        .auth-footer {
            text-align: center;
            margin-top: 25px;
            color: #aaa;
        }

        .auth-footer a {
            color: #d4af37;
        }

        @media (max-width: 500px) {
            .auth-card {
                padding: 25px;
            }
        }
    </style>
</head>

<body>
    <main class="auth-page">
        <div class="auth-card">

            <h1>WELCOME BACK</h1>

            <p class="auth-subtitle">
                Sign in to manage your grooming appointments.
            </p>

            @if ($errors->any())
                <div class="auth-error" role="alert">
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('login.store') }}">
                @csrf

                <div class="auth-group">
                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="{{ old('email') }}"
                        required
                        autocomplete="email"
                    >
                </div>

                <div class="auth-group">
                    <label for="password">Password</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        autocomplete="current-password"
                    >
                </div>

                <button type="submit" class="btn auth-submit">
                    Sign In
                </button>
            </form>

            <p class="auth-footer">
                Don't have an account?
                <a href="{{ route('register') }}">Create Account</a>
            </p>

            <p class="auth-footer">
                <a href="{{ url('/') }}">← Back to Homepage</a>
            </p>

        </div>
    </main>
</body>
</html>
