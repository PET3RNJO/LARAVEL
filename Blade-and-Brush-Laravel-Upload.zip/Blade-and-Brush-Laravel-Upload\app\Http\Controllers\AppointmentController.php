<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Barber;
use App\Models\Service;
use Carbon\CarbonImmutable;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Throwable;

class AppointmentController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Display the Appointment Booking Form
    |--------------------------------------------------------------------------
    */
    public function create(): View
    {
        $services = Service::where('is_active', true)
            ->orderBy('name')
            ->get();

        $barbers = Barber::where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('booking', compact('services', 'barbers'));
    }

    /*
    |--------------------------------------------------------------------------
    | Save a New Appointment
    |--------------------------------------------------------------------------
    */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'service_id' => ['required', 'integer', 'exists:services,id'],
            'barber_id' => ['required', 'integer', 'exists:barbers,id'],
            'appointment_date' => ['required', 'date_format:Y-m-d'],
            'appointment_time' => ['required', 'date_format:H:i'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);

        $timezone = 'Africa/Lusaka';

        $start = CarbonImmutable::createFromFormat(
            '!Y-m-d H:i',
            $data['appointment_date'] . ' ' . $data['appointment_time'],
            $timezone
        );

        if (
            !$start ||
            $start->format('Y-m-d H:i') !==
                $data['appointment_date'] . ' ' . $data['appointment_time'] ||
            $start->lessThanOrEqualTo(CarbonImmutable::now($timezone))
        ) {
            throw ValidationException::withMessages([
                'appointment_date' => 'Please select a valid future appointment.',
            ]);
        }

        $connection = DB::connection();

        if ($connection->getDriverName() !== 'sqlite') {
            throw new \RuntimeException(
                'This booking implementation requires SQLite.'
            );
        }

        /*
         * SQLite BEGIN IMMEDIATE reserves the write transaction
         * before checking availability and creating the booking.
         */
        $connection->getPdo()->exec('BEGIN IMMEDIATE');
        $transactionStarted = true;

        try {
            $service = Service::whereKey($data['service_id'])
                ->where('is_active', true)
                ->first();

            $barber = Barber::whereKey($data['barber_id'])
                ->where('is_active', true)
                ->first();

            if (!$service || !$barber) {
                throw ValidationException::withMessages([
                    'service_id' => 'The selected service or barber is unavailable.',
                ]);
            }

            $end = $start->addMinutes($service->duration_minutes);

            // Demonstration business hours: 08:00 to 18:00.
            $openingTime = $start->setTime(8, 0);
            $closingTime = $start->setTime(18, 0);

            if (
                $start->lessThan($openingTime) ||
                $end->greaterThan($closingTime)
            ) {
                throw ValidationException::withMessages([
                    'appointment_time' =>
                        'The appointment must fit between 08:00 and 18:00.',
                ]);
            }

            // Retrieve all active bookings for this barber on the date.
            
$existingAppointments = Appointment::with('service')
    ->where('barber_id', $barber->id)
    ->whereDate('appointment_date', $data['appointment_date'])
    ->whereIn('status', ['pending', 'confirmed'])
    ->get();


            foreach ($existingAppointments as $appointment) {
                $existingStart = CarbonImmutable::parse(
                    $data['appointment_date'] . ' ' .
                    $appointment->appointment_time,
                    $timezone
                );

                $existingEnd = $existingStart->addMinutes(
                    $appointment->service->duration_minutes
                );

                // Detect overlapping time intervals.
                if (
                    $start->lessThan($existingEnd) &&
                    $end->greaterThan($existingStart)
                ) {
                    throw ValidationException::withMessages([
                        'appointment_time' =>
                            'This barber is already booked during that time.',
                    ]);
                }
            }

            // Save the appointment using the logged-in customer.
            Appointment::create([
                'user_id' => $request->user()->id,
                'barber_id' => $barber->id,
                'service_id' => $service->id,
                'appointment_date' => $data['appointment_date'],
                'appointment_time' => $start->format('H:i:s'),
                'status' => 'pending',
                'notes' => $data['notes'] ?? null,
            ]);

            $connection->getPdo()->exec('COMMIT');
            $transactionStarted = false;

        } catch (Throwable $exception) {
            if ($transactionStarted) {
                $connection->getPdo()->exec('ROLLBACK');
            }

            throw $exception;
        }

        return redirect()
            ->route('booking.create')
            ->with(
                'success',
                'Your appointment request was submitted successfully!'
            );
    }

    /*
    |--------------------------------------------------------------------------
    | Display the Logged-in Customer's Booking History
    |--------------------------------------------------------------------------
    */
    public function index(Request $request): View
    {
        $appointments = Appointment::with(['service', 'barber'])
            ->where('user_id', $request->user()->id)
            ->orderByDesc('appointment_date')
            ->orderByDesc('appointment_time')
            ->paginate(10);

        return view('my-bookings', compact('appointments'));
    }

    /*
    |--------------------------------------------------------------------------
    | Cancel a Customer Appointment
    |--------------------------------------------------------------------------
    */
    public function cancel(
        Request $request,
        Appointment $appointment
    ): RedirectResponse {
        // Ensure the appointment belongs to the logged-in customer.
        abort_unless(
            $appointment->user_id === $request->user()->id,
            403,
            'You are not authorized to cancel this appointment.'
        );

        $connection = DB::connection();

        if ($connection->getDriverName() !== 'sqlite') {
            throw new \RuntimeException(
                'This cancellation implementation requires SQLite.'
            );
        }

        $connection->getPdo()->exec('BEGIN IMMEDIATE');
        $transactionStarted = true;

        try {
            // Re-read the record after obtaining the write reservation.
            $current = Appointment::findOrFail($appointment->id);

            if ($current->user_id !== $request->user()->id) {
                abort(403);
            }

            if (!in_array($current->status, ['pending', 'confirmed'])) {
                throw ValidationException::withMessages([
                    'booking' => 'This appointment cannot be cancelled.',
                ]);
            }

            $appointmentStart = CarbonImmutable::parse(
                $current->appointment_date->format('Y-m-d') .
                ' ' . $current->appointment_time,
                'Africa/Lusaka'
            );

            if (
                $appointmentStart->lessThanOrEqualTo(
                    CarbonImmutable::now('Africa/Lusaka')
                )
            ) {
                throw ValidationException::withMessages([
                    'booking' => 'Past appointments cannot be cancelled.',
                ]);
            }

            // Preserve the record but update its status.
            $current->update([
                'status' => 'cancelled',
            ]);

            $connection->getPdo()->exec('COMMIT');
            $transactionStarted = false;

        } catch (Throwable $exception) {
            if ($transactionStarted) {
                $connection->getPdo()->exec('ROLLBACK');
            }

            throw $exception;
        }

        return redirect()
            ->route('bookings.index')
            ->with('success', 'Appointment cancelled successfully.');
    }
}
