<?php

namespace Database\Seeders;

use App\Models\Barber;
use Illuminate\Database\Seeder;

class BarberSeeder extends Seeder
{
    public function run(): void
    {
        $barbers = [
            [
                'name' => 'James Banda',
                'specialty' => 'Classic Haircuts',
                'bio' => 'Experienced barber specializing in traditional cuts.',
                'photo' => null,
                'is_active' => true,
            ],
            [
                'name' => 'Daniel Mwansa',
                'specialty' => 'Skin Fades',
                'bio' => 'Specialist in modern fades and precision styling.',
                'photo' => null,
                'is_active' => true,
            ],
            [
                'name' => 'Michael Phiri',
                'specialty' => 'Beard Grooming',
                'bio' => 'Expert in beard shaping and detailed grooming.',
                'photo' => null,
                'is_active' => true,
            ],
        ];

        foreach ($barbers as $barber) {
            Barber::updateOrCreate(
                ['name' => $barber['name']],
                $barber
            );
        }
    }
}
