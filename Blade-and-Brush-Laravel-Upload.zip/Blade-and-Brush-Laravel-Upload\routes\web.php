<?php

use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', [AuthController::class, 'showRegister'])
    ->name('register');

Route::post('/register', [AuthController::class, 'register'])
    ->name('register.store');

Route::get('/login', [AuthController::class, 'showLogin'])
    ->name('login');

Route::post('/login', [AuthController::class, 'login'])
    ->name('login.store');

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

Route::get('/booking', [AppointmentController::class, 'create'])
    ->name('booking.create');

Route::post('/booking', [AppointmentController::class, 'store'])
    ->middleware('auth')
    ->name('booking.store');
Route::middleware('guest')->group(function () {
    
Route::get('/register', [AuthController::class, 'showRegister'])
    ->name('register');

Route::post('/register', [AuthController::class, 'register'])
    ->name('register.store');


    Route::get('/login', [AuthController::class, 'showLogin'])
        ->name('login');

    Route::post('/login', [AuthController::class, 'login'])
    ->name('login.store');
});

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');
    
Route::get('/my-bookings', [AppointmentController::class, 'index'])
    ->middleware('auth')
    ->name('bookings.index');

Route::patch(
    '/my-bookings/{appointment}/cancel',
    [AppointmentController::class, 'cancel']
)
    ->middleware('auth')
    ->name('bookings.cancel');
