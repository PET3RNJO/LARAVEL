
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Blade & Brush | Premium Grooming</title>
    <meta name="description" content="Discover premium haircuts, beard grooming and classic barbering at Blade & Brush.">

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <script src="{{ asset('js/main.js') }}" defer></script>
</head>

<body>
    <!-- Navigation -->
    <header class="site-header">
        <nav class="navbar container" aria-label="Main navigation">
            <a class="brand" href="#home">
                <span class="brand-mark">B&B</span>
                <span>BLADE <em>&</em> BRUSH</span>
            </a>

            <button class="menu-toggle" type="button"
                    aria-label="Open navigation"
                    aria-expanded="false"
                    aria-controls="nav-links">
                ☰
            </button>

            <div class="nav-links" id="nav-links">
                <a href="#home">Home</a>
                <a href="#services">Services</a>
                <a href="#about">About Us</a>
                <a href="#barbers">Our Barbers</a>
                <a href="#contact">Contact</a>
                
@auth
    <a href="{{ route('bookings.index') }}">
    My Bookings
</a>
    <span class="nav-user">
        Welcome, {{ auth()->user()->name }}
    </span>

    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="btn btn-small">
            Logout
        </button>
    </form>
@else
    <a href="{{ route('login') }}">Login</a>
    <a href="{{ route('register') }}">Register</a>
@endauth

                <a class="btn btn-small" href="{{ route('booking.create') }}">
    Book Now
</a>

            </div>
        </nav>
    </header>

    <main>
        <!-- Hero -->
        <section class="hero" id="home">
            <div class="container hero-content">
                <p class="eyebrow">WELCOME TO BLADE & BRUSH</p>

                <h1>WHERE STYLE<br>MEETS <span>PRECISION.</span></h1>

                <p class="hero-description">
                    Experience the art of professional grooming.
                    Sharp cuts, clean fades and timeless style,
                    delivered by skilled barbers.
                </p>

                <div class="hero-actions">
                <a href="{{ route('booking.create') }}" class="btn">
    Book Your Appointment →
</a>
                    <a href="#services" class="btn btn-outline">Explore Services</a>
                </div>

                <div class="hero-caption">
                    PREMIUM CUTS • CLASSIC STYLE • MODERN GROOMING
                </div>
            </div>
        </section>

        <!-- Services -->
        <section class="section" id="services">
            <div class="container">
                <div class="section-heading">
                    <p class="eyebrow">WHAT WE OFFER</p>
                    <h2>Our Signature <span>Services</span></h2>
                    <p>Exceptional grooming, tailored to your personal style.</p>
                </div>

                <div class="service-grid">
                    <article class="service-card">
                        <div class="service-icon">✂</div>
                        <h3>Classic Haircut</h3>
                        <p>Professional haircut with expert finishing and styling.</p>
                        <div class="service-bottom">
                            <strong>K150</strong>
                            <span>45 min</span>
                        </div>
                    </article>

                    <article class="service-card">
                        <div class="service-icon">◈</div>
                        <h3>Skin Fade</h3>
                        <p>Sharp fades, clean transitions and precise detailing.</p>
                        <div class="service-bottom">
                            <strong>K180</strong>
                            <span>50 min</span>
                        </div>
                    </article>

                    <article class="service-card">
                        <div class="service-icon">✦</div>
                        <h3>Beard Grooming</h3>
                        <p>Expert beard shaping, trimming and neat finishing.</p>
                        <div class="service-bottom">
                            <strong>K80</strong>
                            <span>25 min</span>
                        </div>
                    </article>

                    <article class="service-card">
                        <div class="service-icon">★</div>
                        <h3>Full Grooming</h3>
                        <p>A complete haircut, beard treatment and styling session.</p>
                        <div class="service-bottom">
                            <strong>K250</strong>
                            <span>75 min</span>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- About -->
        <section class="section about-section" id="about">
            <div class="container about-grid">
                <div class="about-image">
                    <img
                        src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1100&q=85"
                        alt="Classic barbershop interior"
                        loading="lazy">
                </div>

                <div class="about-content">
                    <p class="eyebrow">THE BLADE & BRUSH EXPERIENCE</p>
                    <h2>More Than Just<br><span>A Haircut.</span></h2>
                    <p>
                        At Blade & Brush, grooming is more than a routine.
                        It's an experience built around craftsmanship,
                        attention to detail and personal style.
                    </p>
                    <p>
                        From classic cuts to modern fades, our mission
                        is to help every client look sharp and feel confident.
                    </p>
                    <a href="#booking" class="btn">Experience the Difference →</a>
                </div>
            </div>
        </section>

        <!-- Barber profiles -->
        <section class="section" id="barbers">
            <div class="container">
                <div class="section-heading">
                    <p class="eyebrow">THE PROFESSIONALS</p>
                    <h2>Meet Our <span>Barbers</span></h2>
                    <p>Dedicated to precision and quality grooming.</p>
                </div>

                <div class="barber-grid">
                    <article class="barber-card">
                        <img
                            src="https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=850&q=85"
                            alt="Professional barber at work"
                            loading="lazy">
                        <div class="barber-info">
                            <h3>Master Barber</h3>
                            <p>Classic Cuts & Precision Styling</p>
                        </div>
                    </article>

                    <article class="barber-card">
                        <img
                            src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=850&q=85"
                            alt="Barbershop styling station"
                            loading="lazy">
                        <div class="barber-info">
                            <h3>Fade Specialist</h3>
                            <p>Modern Fades & Hair Design</p>
                        </div>
                    </article>

                    <article class="barber-card">
                        <img
                            src="https://images.unsplash.com/photo-1599351431613-18ef1fdd27e1?auto=format&fit=crop&w=850&q=85"
                            alt="Barbershop grooming tools"
                            loading="lazy">
                        <div class="barber-info">
                            <h3>Grooming Specialist</h3>
                            <p>Beard Styling & Detail Work</p>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Booking -->
        <section class="booking-section" id="booking">
            <div class="container booking-content">
                <p class="eyebrow">YOUR NEXT LOOK STARTS HERE</p>
                <h2>READY FOR A <span>FRESH CUT?</span></h2>
                <p>
                    Your style deserves professional attention.
                    Online appointment booking is coming next.
                </p>
                <span class="btn btn-disabled">Online Booking Coming Soon</span>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer" id="contact">
        <div class="container footer-grid">
            <div>
                <h3>BLADE <span>&</span> BRUSH</h3>
                <p>Precision grooming. Timeless confidence.</p>
            </div>

            <div>
                <h4>Explore</h4>
                <a href="#home">Home</a>
                <a href="#services">Services</a>
                <a href="#barbers">Our Barbers</a>
            </div>

            <div>
                <h4>Appointments</h4>
                <p>Online booking will be available soon.</p>
                <p>Location and contact details to be announced.</p>
            </div>
        </div>

        <div class="container footer-bottom">
            &copy; {{ date('Y') }} Blade & Brush.
            All Rights Reserved.
        </div>
    </footer>
</body>
</html>
