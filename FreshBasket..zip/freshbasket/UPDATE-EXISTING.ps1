# Updates only the photo and supermarket-section files in existing installations.
$ErrorActionPreference = 'Stop'
$source = $PSScriptRoot
$live = Join-Path $env:USERPROFILE 'Desktop\freshbasket'
$documents = Join-Path $env:USERPROFILE 'Documents\FreshBasket\freshbasket'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$files = @(
 'config/catalogue.php',
 'database/migrations/2026_10_15_000003_organise_supermarket_sections.php',
 'database/seeders/DatabaseSeeder.php',
 'app/Models/Product.php',
 'app/Http/Controllers/ShopController.php',
 'app/Http/Controllers/StoreController.php',
 'resources/views/product-form.blade.php',
 'resources/views/shop.blade.php',
 'resources/views/cart.blade.php',
 'resources/views/layout.blade.php',
 'public/style.css',
 'tests/Feature/StoreManagementTest.php',
 'tests/Feature/SupermarketSectionsTest.php',
 'public/images/catalogue/notebooks.webp',
 'public/images/catalogue/oil.webp',
 'public/images/catalogue/milk.webp',
 'public/images/catalogue/rice.webp',
 'public/images/catalogue/biscuits.webp',
 'public/images/catalogue/tomatoes.webp',
 'public/images/catalogue/frozen-veg.webp',
 'public/images/catalogue/detergent.webp',
 'public/images/catalogue/avocados.webp',
 'public/images/catalogue/apples.webp',
 'public/images/catalogue/ice-cream.webp',
 'public/images/catalogue/eggs.webp',
 'public/images/catalogue/wrap.webp',
 'public/images/catalogue/bananas.webp',
 'public/images/catalogue/chicken.webp',
 'public/images/catalogue/juice.webp',
 'public/images/catalogue/bread.webp',
 'public/images/catalogue/meal.webp',
 'public/images/catalogue/hero.webp',
 'START-HERE.txt',
 'ASSET-NOTES.txt',
 'UPDATE-EXISTING.ps1'
)
if (!(Test-Path (Join-Path $live 'vendor/autoload.php'))) { throw 'The installed Desktop/freshbasket Laravel application could not be found.' }
foreach ($folder in @($live, $documents)) {
 if (!(Test-Path (Join-Path $folder 'artisan'))) { throw ('Expected Laravel folder not found: '+$folder) }
 if ($folder -eq $source) { continue }
 $backup = Join-Path $env:USERPROFILE ('Desktop\FreshBasket-source-backup-'+(Split-Path (Split-Path $folder -Parent) -Leaf)+'-'+$stamp+'.zip')
 Push-Location $folder
 try { Compress-Archive -Path app,config,routes,resources,database,public,tests -DestinationPath $backup } finally { Pop-Location }
 foreach ($name in $files) {
  $from = Join-Path $source $name
  $to = Join-Path $folder $name
  if (!(Test-Path $from)) { throw ('Missing update source: '+$from) }
  [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($to)) | Out-Null
  Copy-Item -LiteralPath $from -Destination $to -Force
 }
}
Push-Location $live
try {
 php artisan migrate --force
 if ($LASTEXITCODE -ne 0) { throw 'Migration failed. Original source and database backups were retained.' }
 php artisan view:clear
 php artisan test --compact
 if ($LASTEXITCODE -ne 0) { throw 'Tests failed. Do not distribute the updated project yet.' }
 php artisan view:cache
 if ($LASTEXITCODE -ne 0) { throw 'View compilation failed.' }
} finally { Pop-Location }
$zip = Join-Path $env:USERPROFILE 'Documents\FreshBasket..zip'
if (Test-Path $zip) { Copy-Item $zip ($zip+'.before-photos-'+$stamp+'.bak') }
$tempZip = $zip+'.new-'+$stamp
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open($tempZip,[IO.Compression.ZipArchiveMode]::Create)
try {
 foreach ($file in Get-ChildItem $documents -Recurse -File -Force) {
  $relative = $file.FullName.Substring($documents.Length+1).Replace('\','/')
  if ($relative -match '^(vendor|node_modules|\.git)/' -or $relative -eq '.env' -or $relative -match '\.(sqlite|log)(-|$)' -or ($relative.StartsWith('storage/') -and $file.Name -ne '.gitignore') -or ($relative.StartsWith('bootstrap/cache/') -and $file.Name -ne '.gitignore')) { continue }
  if ($relative -notmatch '^(app/|bootstrap/|config/|database/factories/|database/migrations/|database/seeders/|public/|resources/|routes/|tests/|storage/|artisan$|composer\.(json|lock)$|phpunit\.xml$|\.env\.example$|\.gitignore$|INSTALL\.ps1$|UPDATE-EXISTING\.ps1$|START-HERE\.txt$|ASSET-NOTES\.txt$)') { continue }
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,('freshbasket/'+$relative),[IO.Compression.CompressionLevel]::Optimal) | Out-Null
 }
} finally { $archive.Dispose() }
Move-Item $tempZip $zip -Force
Write-Host 'Both existing folders and Documents/FreshBasket..zip have been updated.'
Start-Process 'http://freshbasket.test/?updated=photos'
