<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
class AuthController extends Controller {
 public function form(string $mode='login') { return view('auth',compact('mode')); }
 public function register(Request $r) {
  $d=$r->validate(['name'=>'required|string|max:100','email'=>'required|email|max:254|unique:users','password'=>'required|string|min:8|confirmed']);
  $u=User::create(['name'=>$d['name'],'email'=>$d['email'],'password'=>Hash::make($d['password'])]);
  Auth::login($u); $r->session()->regenerate(); return redirect('/');
 }
 public function login(Request $r) {
  $d=$r->validate(['email'=>'required|email','password'=>'required|string']);
  if(!Auth::attempt($d)) throw ValidationException::withMessages(['email'=>'The email or password is incorrect.']);
  $r->session()->regenerate(); return redirect()->intended($r->user()->is_admin?'/admin/stores':($r->user()->stores()->exists()?'/supplier':'/orders')); 
 }
 public function logout(Request $r) { Auth::logout(); $r->session()->invalidate(); $r->session()->regenerateToken(); return redirect('/'); }
}
