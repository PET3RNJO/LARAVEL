<?php
namespace App\Http\Controllers;
use App\Models\{Store,User,Product};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB,Storage};
use Illuminate\Validation\Rule;
class StoreController extends Controller {
 private function admin(Request $r): void { abort_unless($r->user()->is_admin,403); }
 private function staff(Request $r,Store $store): void {
  abort_unless($r->user()->is_admin || ($store->active && $store->users()->whereKey($r->user()->id)->exists()),403);
 }
 private function audit(Request $r,string $action,string $type,int $id,array $details): void {
  DB::table('store_audits')->insert(['actor_id'=>$r->user()->id,'action'=>$action,'target_type'=>$type,'target_id'=>$id,'details'=>json_encode($details,JSON_THROW_ON_ERROR),'created_at'=>now()]);
 }
 public function stores(Request $r) {
  $this->admin($r);return view('stores-admin',['stores'=>Store::with('users')->orderBy('name')->get()]);
 }
 public function createStore(Request $r) {
  $this->admin($r);$d=$r->validate(['name'=>'required|string|max:100|unique:stores,name']);
  DB::transaction(function()use($r,$d){$s=Store::create($d);$this->audit($r,'store_created','store',$s->id,$d);});
  return back()->with('success','Store created. Give a registered account access below.');
 }
 public function updateStore(Request $r,Store $store) {
  $this->admin($r);$d=$r->validate(['active'=>'required|boolean','reason'=>'nullable|string|max:500']);
  if((bool)$d['active']===$store->active)return back();
  if(!$d['active'])$r->validate(['reason'=>'required|string|min:3|max:500']);
  DB::transaction(function()use($r,$store,$d){$old=$store->active;$store->update(['active'=>$d['active']]);$this->audit($r,'store_status','store',$store->id,['old'=>$old,'new'=>(bool)$d['active'],'reason'=>$d['reason']??null]);});
  return back()->with('success','Store status updated.');
 }
 public function grant(Request $r,Store $store) {
  $this->admin($r);$d=$r->validate(['email'=>'required|email|exists:users,email']);$user=User::where('email',$d['email'])->firstOrFail();
  DB::transaction(function()use($r,$store,$user){if(!$store->users()->whereKey($user->id)->exists()){$store->users()->attach($user->id);$this->audit($r,'access_granted','store',$store->id,['user_id'=>$user->id]);}});
  return back()->with('success','Store access granted. The user can now open the Supplier dashboard.');
 }
 public function revoke(Request $r,Store $store,User $user) {
  $this->admin($r);$d=$r->validate(['reason'=>'required|string|min:3|max:500']);
  DB::transaction(function()use($r,$store,$user,$d){if($store->users()->detach($user->id))$this->audit($r,'access_revoked','store',$store->id,['user_id'=>$user->id,'reason'=>$d['reason']]);});
  return back()->with('success','Store access removed.');
 }
 public function dashboard(Request $r) {
  $stores=$r->user()->is_admin?Store::orderBy('name')->get():$r->user()->stores()->where('active',true)->orderBy('name')->get();
  $products=Product::whereIn('store_id',$stores->pluck('id'))->with('shop')->latest()->paginate(15);
  return view('supplier',compact('stores','products'));
 }
 public function form(Request $r,Store $store,?Product $product=null) {
  $this->staff($r,$store);if($product)abort_unless($product->store_id===$store->id,404);
  return view('product-form',['store'=>$store,'product'=>$product??new Product]);
 }
 public function save(Request $r,Store $store,?Product $product=null) {
  $this->staff($r,$store);if($product)abort_unless($product->store_id===$store->id,404);
  $d=$r->validate(['name'=>'required|string|max:150','category'=>['required','string',Rule::in(array_unique(array_merge(array_keys(config('catalogue.sections')),[$product?->category ?? '']))) ],'price'=>['required','regex:/^\d{1,6}(\.\d{1,2})?$/','numeric','min:0.01','max:999999.99'],'unit'=>'required|string|max:80','description'=>'nullable|string|max:2000','image'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:2048','available'=>'required|boolean','submit'=>'required|in:draft,pending']);
  $path=$r->hasFile('image')?$r->file('image')->store('products','public'):null;
  try {
   DB::transaction(function()use($r,$store,$product,$d,$path){
    $parts=explode('.',$d['price']);$price=((int)$parts[0]*100)+(int)str_pad($parts[1]??'',2,'0');
    $data=['store_id'=>$store->id,'store'=>$store->name,'name'=>$d['name'],'category'=>$d['category'],'price'=>$price,'unit'=>$d['unit'],'description'=>$d['description']??null,'available'=>(bool)$d['available'],'status'=>$d['submit'],'review_reason'=>null];
    if($path)$data['image_path']=$path;
    if(!$product)$data['icon']='Basket';
    $old=$product?->status;$saved=$product??new Product;$saved->fill($data)->save();
    $this->audit($r,'product_saved','product',$saved->id,['old_status'=>$old,'new_status'=>$saved->status,'store_id'=>$store->id]);
   });
  }catch(\Throwable $e){if($path)Storage::disk('public')->delete($path);throw $e;}
  return redirect('/supplier')->with('success',$d['submit']==='pending'?'Product submitted for admin review.':'Draft saved. This product is private.');
 }
 public function reviews(Request $r) {
  $this->admin($r);return view('product-reviews',['products'=>Product::with('shop')->where('status','pending')->latest()->paginate(15)]);
 }
 public function review(Request $r,Product $product) {
  $this->admin($r);$d=$r->validate(['decision'=>['required',Rule::in(['published','rejected'])],'reason'=>'nullable|string|max:500']);
  if($d['decision']==='rejected')$r->validate(['reason'=>'required|string|min:3|max:500']);
  DB::transaction(function()use($r,$product,$d){$locked=Product::lockForUpdate()->findOrFail($product->id);abort_unless($locked->status==='pending',422,'Only pending products can be reviewed.');$locked->update(['status'=>$d['decision'],'review_reason'=>$d['reason']??null]);$this->audit($r,'product_reviewed','product',$locked->id,['old_status'=>'pending','new_status'=>$d['decision'],'reason'=>$d['reason']??null]);});
  return back()->with('success','Product review saved.');
 }
 public function image(Request $r,Product $product) {
  $allowed=$product->status==='published' && $product->shop?->active;
  if(!$allowed && $r->user())$allowed=$r->user()->is_admin || ($product->shop?->active && $product->shop->users()->whereKey($r->user()->id)->exists());
  abort_unless($allowed && $product->image_path,404);
  return Storage::disk('public')->response($product->image_path,null,['X-Content-Type-Options'=>'nosniff','Cache-Control'=>'private, no-store']);
 }
}
