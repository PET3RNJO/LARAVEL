<?php
namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ShopController extends Controller {
 public function index(Request $r) {
  $products=Product::query()->publiclyListed()->where('available',true)
   ->when($r->filled('q'),fn($q)=>$q->where('name','like','%'.$r->string('q').'%'))
   ->when($r->filled('store'),fn($q)=>$q->where('store',$r->string('store')))
   ->when($r->filled('category'),fn($q)=>$q->where('category',$r->string('category')))->get();
  $counts=Product::publiclyListed()->where('available',true)->when($r->filled('store'),fn($q)=>$q->where('store',$r->string('store')))->selectRaw('category, count(*) as total')->groupBy('category')->pluck('total','category');
  $sections=collect(config('catalogue.sections'))->map(fn($meta,$name)=>array_merge($meta,['count'=>(int)($counts[$name]??0)]));
  foreach($counts as $name=>$count)if(!$sections->has($name))$sections->put($name,['image'=>'hero','description'=>'More everyday essentials.','count'=>(int)$count]);
  $categories=$sections->keys();$stores=\App\Models\Store::where('active',true)->orderBy('name')->get();return view('shop',compact('products','categories','stores','sections'));
 }
 private function basket(Request $r): array {
  $cart=$r->session()->get('cart',[]); $rows=[];$subtotal=0;
  foreach(Product::whereIn('id',array_keys($cart))->get() as $p) {
   $qty=(int)$cart[$p->id]; $line=$p->price*$qty; $subtotal+=$line;
   $rows[]=['id'=>$p->id,'name'=>$p->name,'store'=>$p->store,'icon'=>$p->icon,'image'=>$p->catalogue_image,'available'=>$p->canPurchase(),'price'=>$p->price,'quantity'=>$qty,'line'=>$line];
  }
  return ['rows'=>$rows,'subtotal'=>$subtotal,'delivery'=>count($rows)?3500:0,'total'=>$subtotal+(count($rows)?3500:0)];
 }
 public function cart(Request $r) { return view('cart',$this->basket($r)); }
 public function add(Request $r,Product $product) {
  abort_unless($product->canPurchase(),422,'This product is unavailable.');
  $cart=$r->session()->get('cart',[]);$cart[$product->id]=min(20,($cart[$product->id]??0)+1);
  $r->session()->put('cart',$cart); return back()->with('success','Added to your basket.');
 }
 public function update(Request $r,Product $product) {
  $d=$r->validate(['quantity'=>'required|integer|min:0|max:20']);$cart=$r->session()->get('cart',[]);
  if($d['quantity']==0) unset($cart[$product->id]); else $cart[$product->id]=(int)$d['quantity'];
  $r->session()->put('cart',$cart);return back();
 }
 public function checkout(Request $r) { $basket=$this->basket($r); if(!$basket['rows']) return redirect('/cart');$r->session()->put('checkout_nonce',bin2hex(random_bytes(24)));return view('checkout',$basket); }
 public function place(Request $r) {
  $d=$r->validate(['phone'=>['required','regex:/^\+?[0-9 ()-]{9,20}$/'],'address'=>'required|string|min:10|max:1000','requests'=>'nullable|string|max:2000','checkout_token'=>'required|string']);
  // A session nonce makes a repeated checkout submission return the original order.
  if($r->session()->get('last_checkout.token')===$d['checkout_token']) return redirect('/orders/'.$r->session()->get('last_checkout.id'));
  abort_unless(hash_equals((string)$r->session()->get('checkout_nonce'),$d['checkout_token']),419);
  $o=DB::transaction(function() use($r,$d) {
   $b=$this->basket($r); abort_unless(count($b['rows']),422,'Your basket is empty.');
   foreach($b['rows'] as $row) abort_unless($row['available'],422,'A product in your basket is unavailable.');
   return Order::create(['user_id'=>$r->user()->id,'items'=>$b['rows'],'subtotal'=>$b['subtotal'],'delivery_fee'=>$b['delivery'],'total'=>$b['total'],'phone'=>$d['phone'],'address'=>$d['address'],'requests'=>$d['requests']??null]);
  });
  $r->session()->forget('cart');$r->session()->put('last_checkout',['token'=>$d['checkout_token'],'id'=>$o->id]);
  return redirect('/orders/'.$o->id)->with('success','Order placed. Pay on delivery.');
 }
 public function orders(Request $r) { return view('orders',['orders'=>Order::where('user_id',$r->user()->id)->latest()->paginate(12)]); }
 public function show(Request $r,Order $order) { abort_unless($order->user_id===$r->user()->id || $r->user()->is_admin,403);return view('order',compact('order')); }
 public function admin(Request $r) { abort_unless($r->user()->is_admin,403);return view('admin',['orders'=>Order::with('user')->latest()->paginate(15)]); }
 public function status(Request $r,Order $order) {
  abort_unless($r->user()->is_admin,403);
  $d=$r->validate(['status'=>'required|in:placed,confirmed,shopping,out_for_delivery,delivered,cancelled','courier'=>'nullable|string|max:100','delivery_reference'=>'nullable|string|max:100']);
  $next=['placed'=>['confirmed','cancelled'],'confirmed'=>['shopping','cancelled'],'shopping'=>['out_for_delivery','cancelled'],'out_for_delivery'=>['delivered'],'delivered'=>[],'cancelled'=>[]];
  DB::transaction(function() use($order,$d,$next) {
   $current=Order::lockForUpdate()->findOrFail($order->id);
   abort_unless($d['status']===$current->status || in_array($d['status'],$next[$current->status],true),422,'That order status change is not allowed.');$current->update($d);
  });return back()->with('success','Order updated.');
 }
}
