<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Store extends Model {
 protected $guarded = [];
 protected function casts(): array { return ['active'=>'boolean']; }
 public function users() { return $this->belongsToMany(User::class)->withTimestamps(); }
 public function products() { return $this->hasMany(Product::class); }
}
