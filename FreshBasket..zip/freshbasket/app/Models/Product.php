<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Product extends Model {
 protected $guarded = [];
 protected function casts(): array { return ['available'=>'boolean']; }
 public function getCatalogueImageAttribute(): string {
  if($this->image_path)return url('/products/'.$this->id.'/image');
  $image=config('catalogue.products.'.$this->name.'.image') ?? config('catalogue.sections.'.$this->category.'.image') ?? 'hero';
  return asset('images/catalogue/'.$image.'.webp');
 }
 public function shop() { return $this->belongsTo(Store::class,'store_id'); }
 public function scopePubliclyListed($query) {
  return $query->where('status','published')->whereHas('shop',fn($q)=>$q->where('active',true));
 }
 public function canPurchase(): bool { return $this->available && $this->status==='published' && (bool)$this->shop?->active; }
}
