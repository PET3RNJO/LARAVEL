<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Order extends Model {
 protected $guarded = [];
 protected function casts(): array { return ['items'=>'array']; }
 public function user() { return $this->belongsTo(User::class); }
}
