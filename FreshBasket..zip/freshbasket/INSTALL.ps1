$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
composer install --no-interaction --prefer-dist
if ($LASTEXITCODE -ne 0) { throw 'Composer installation failed.' }
if (!(Test-Path '.env')) { Copy-Item '.env.example' '.env'; php artisan key:generate }
if (!(Test-Path 'database/database.sqlite')) { New-Item 'database/database.sqlite' -ItemType File | Out-Null }
php artisan migrate --seed --force
if ($LASTEXITCODE -ne 0) { throw 'Migration failed.' }
php artisan test --compact
if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
herd link freshbasket
Write-Host 'Open http://freshbasket.test while Herd is running.'
