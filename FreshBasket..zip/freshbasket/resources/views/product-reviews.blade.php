@extends('layout')
@section('content')
<div class="page-heading"><div class="eyebrow">ADMINISTRATION</div><h1>Review store listings.</h1><p>Approve a listing to publish it. Rejected listings stay private and can be edited and resubmitted.</p></div>
@forelse($products as $product)
<section class="panel admin-order"><div class="two-col"><div><span class="eyebrow">{{ $product->shop->name }}</span><h2>{{ $product->name }}</h2><p>{{ $product->category }} &middot; {{ $product->unit }} &middot; K{{ number_format($product->price/100,2) }}</p><p>{{ $product->description }}</p><p class="muted">{{ $product->available?'Marked available':'Marked unavailable' }} | Store {{ $product->shop->active?'active':'paused' }}</p>@if($product->image_path)<img class="review-photo" src="/products/{{ $product->id }}/image" alt="{{ $product->name }}">@endif</div><form method="post" action="/admin/products/{{ $product->id }}">@csrf @method('PATCH')<label>Decision<select name="decision"><option value="published">Approve and publish</option><option value="rejected">Reject</option></select></label><label>Review note (required for rejection)<textarea name="reason" maxlength="500"></textarea></label><button>Save decision</button></form></div></section>
@empty
<section class="panel"><h2>All caught up.</h2><p>No products awaiting review.</p></section>
@endforelse
{{ $products->links() }}
@endsection
