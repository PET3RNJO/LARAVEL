@extends('layout')
@section('content')
<div class="page-heading"><div class="eyebrow">ADMINISTRATION</div><h1>Stores &amp; account access.</h1><p>Create a store, then give a registered account permission to manage its listings.</p></div>
<section class="panel"><h2>Add a store</h2><form class="filters" action="/admin/stores" method="post">@csrf<label>Store name<input name="name" required maxlength="100" value="{{ old('name') }}" placeholder="Supermarket or supplier name"></label><button>Create store</button></form></section>
@foreach($stores as $store)
<section class="panel admin-order"><div class="section-heading"><h2>{{ $store->name }}</h2><span class="badge">{{ $store->active?'Active':'Paused' }}</span></div>
<div class="two-col"><div><h3>Give an account access</h3><p class="muted">The supplier must register first. Access is limited to this store.</p><form method="post" action="/admin/stores/{{ $store->id }}/members">@csrf<label>Registered email<input type="email" name="email" required placeholder="store@example.com"></label><button>Grant store access</button></form>
<h3>Store team</h3>@forelse($store->users as $member)
<div class="member-row"><strong>{{ $member->name }}</strong><p>{{ $member->email }}</p><form method="post" action="/admin/stores/{{ $store->id }}/members/{{ $member->id }}">@csrf @method('DELETE')<label>Reason for removing access<input name="reason" required minlength="3" maxlength="500"></label><button class="text">Remove access</button></form></div>
@empty
<p class="muted">No store accounts assigned yet.</p>
@endforelse
</div><div><h3>Store availability</h3><p class="muted">Pausing hides every product from customers and prevents new purchases. Existing orders are preserved.</p><form method="post" action="/admin/stores/{{ $store->id }}">@csrf @method('PATCH')<input type="hidden" name="active" value="{{ $store->active?0:1 }}"><label>Reason<input name="reason" maxlength="500" @required($store->active)></label><button>{{ $store->active?'Pause store':'Activate store' }}</button></form><p><a href="/supplier/stores/{{ $store->id }}/products/create">Add a product &rarr;</a></p></div></div></section>
@endforeach
@endsection
