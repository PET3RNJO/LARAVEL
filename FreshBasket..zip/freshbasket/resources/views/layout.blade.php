<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>FreshBasket | Everyday essentials, delivered</title><link rel="stylesheet" href="{{ asset('style.css') }}?v=3"></head>
<body><div class="topbar">A little less running around. A little more living. <span>Lusaka delivery &middot; K35 flat fee</span></div>
<header><a class="logo" href="/">&#9682; freshbasket<span>YOUR EVERYDAY, SORTED.</span></a><nav><a href="/">Shop essentials</a><a href="/orders">My orders</a><a class="basket" href="/cart">Basket ({{ array_sum(session('cart',[])) }})</a>
@auth
<a href="/supplier">Supplier dashboard</a>
@if(auth()->user()->is_admin)
<a href="/admin">Admin orders</a><a href="/admin/stores">Stores &amp; access</a><a href="/admin/products">Product reviews</a>
@endif
<form method="post" action="/logout">@csrf<button class="text">Log out</button></form>
@else
<a href="/login">Sign in &rarr;</a><a href="/login?area=supplier">Store sign in</a>
@endauth
</nav></header>
<main>@if(session('success'))<div class="notice" role="status">{{ session('success') }}</div>@endif
@if($errors->any())<div class="errors" role="alert">@foreach($errors->all() as $error)<p>{{ $error }}</p>@endforeach</div>@endif
@yield('content')</main><footer><a class="logo" href="/">&#9682; freshbasket</a><p>Groceries, household essentials, and a little time back.</p><small>Learning project &middot; Sample catalogue and prices &middot; Independent demo, unaffiliated with the listed retailers.<br>Orders and delivery are coordinated manually. No live retailer, payment, or Yango connection.</small></footer></body></html>
