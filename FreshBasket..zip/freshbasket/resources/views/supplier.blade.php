@extends('layout')
@section('content')
<div class="page-heading"><div class="eyebrow">STORE WORKSPACE</div><h1>Your shelves, online.</h1><p>Manage products and prices for your assigned stores. Submitted listings appear publicly after admin approval.</p></div>
<div class="store-links">@forelse($stores as $store)
<a class="button" href="/supplier/stores/{{ $store->id }}/products/create">Add product to {{ $store->name }} &rarr;</a>
@empty
<div class="panel"><h2>Your account is ready.</h2><p>An administrator needs to assign you to an active store before you can post products. Give them your registered email: <strong>{{ auth()->user()->email }}</strong>.</p></div>
@endforelse
</div>
@foreach($products as $product)
<section class="panel listing-row"><div><span class="eyebrow">{{ $product->shop->name }}</span><h2>{{ $product->name }}</h2><p>K{{ number_format($product->price/100,2) }} / {{ $product->unit }} &middot; {{ $product->category }}</p>@if($product->review_reason)<p class="errors">Review note: {{ $product->review_reason }}</p>@endif</div><div><span class="badge">{{ $product->status }}</span><p class="muted">{{ $product->available?'Available':'Unavailable' }}</p><a class="button" href="/supplier/stores/{{ $product->store_id }}/products/{{ $product->id }}/edit">Edit listing</a></div></section>
@endforeach
{{ $products->links() }}
@endsection
