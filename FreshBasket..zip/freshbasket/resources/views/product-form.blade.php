@extends('layout')
@section('content')
<div class="page-heading"><div class="eyebrow">{{ $store->name }}</div><h1>{{ $product->exists?'Edit your listing.':'Put it on the shelf.' }}</h1><p>Save a private draft or submit for admin review. Editing a published listing removes it from the public catalogue until approved again.</p></div>
<section class="panel product-editor"><form method="post" enctype="multipart/form-data" action="/supplier/stores/{{ $store->id }}/products{{ $product->exists?'/'.$product->id:'' }}">@csrf
@if($product->exists)
@method('PUT')
@endif
<label>Product name<input name="name" value="{{ old('name',$product->name) }}" required maxlength="150"></label>
<div class="two-col"><label>Supermarket section<select name="category" required><option value="">Choose a section</option>
@foreach(array_keys(config('catalogue.sections')) as $section)
<option value="{{ $section }}" @selected(old('category',$product->category)===$section)>{{ $section }}</option>
@endforeach
@if($product->category && !array_key_exists($product->category,config('catalogue.sections')))
<option selected value="{{ $product->category }}">{{ $product->category }}</option>
@endif
</select></label><label>Price in kwacha (K)<input type="number" name="price" value="{{ old('price',$product->exists?number_format($product->price/100,2,'.',''):'') }}" required min="0.01" max="999999.99" step="0.01"></label></div>
<label>Size or unit<input name="unit" value="{{ old('unit',$product->unit) }}" required maxlength="80" placeholder="1 kg, 500 ml, tray of 15..."></label><label>Description (optional)<textarea name="description" maxlength="2000">{{ old('description',$product->description) }}</textarea></label>
<label>Product photo (optional)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><span class="muted">JPG, PNG or WebP, up to 2 MB. Existing photo stays unless replaced.</span></label>
@if($product->image_path)<img class="review-photo" src="/products/{{ $product->id }}/image" alt="Current product photo">@endif
<label>Availability<select name="available"><option value="1" @selected(old('available',$product->exists?(int)$product->available:1)==1)>Available</option><option value="0" @selected(old('available',$product->exists?(int)$product->available:1)==0)>Unavailable</option></select></label>
<div class="form-actions"><button name="submit" value="pending">Submit for review</button><button class="secondary" name="submit" value="draft" formnovalidate>Save draft</button><a href="/supplier">Back to dashboard</a></div></form></section>
@endsection
