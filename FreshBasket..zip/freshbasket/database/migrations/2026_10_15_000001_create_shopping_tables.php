<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::table('users', function(Blueprint $t) { $t->boolean('is_admin')->default(false); });
  Schema::create('products', function(Blueprint $t) {
   $t->id(); $t->string('name'); $t->string('store'); $t->string('category');
   $t->unsignedInteger('price'); $t->string('unit'); $t->string('icon'); $t->boolean('available')->default(true); $t->timestamps();
  });
  Schema::create('orders', function(Blueprint $t) {
   $t->id(); $t->foreignId('user_id')->constrained()->restrictOnDelete(); $t->json('items');
   $t->unsignedInteger('subtotal'); $t->unsignedInteger('delivery_fee'); $t->unsignedInteger('total');
   $t->string('phone'); $t->text('address'); $t->text('requests')->nullable();
   $t->string('status')->default('placed'); $t->string('courier')->nullable(); $t->string('delivery_reference')->nullable(); $t->timestamps();
  });
 }
 public function down(): void { Schema::dropIfExists('orders'); Schema::dropIfExists('products'); Schema::table('users',fn(Blueprint $t)=>$t->dropColumn('is_admin')); }
};
