<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
return new class extends Migration {
 public function up(): void {
  foreach(['Fresh produce'=>'Fruit & vegetables','Meat'=>'Meat & poultry','Household'=>'Household & cleaning'] as $old=>$new) DB::table('products')->where('category',$old)->update(['category'=>$new]);
  // Expand only the original demo stores; preserve suppliers' prices and uploads.
  foreach(DB::table('stores')->whereIn('name',['Shoprite','Pick n Pay'])->get() as $store) {
   if(!DB::table('products')->where('store_id',$store->id)->where('name','Bananas')->exists()) continue;
   foreach(config('catalogue.products') as $name=>$item) {
    if(DB::table('products')->where('store_id',$store->id)->where('name',$name)->exists())continue;
    DB::table('products')->insert(['store_id'=>$store->id,'store'=>$store->name,'name'=>$name,'category'=>$item['category'],'price'=>$item['price'],'unit'=>$item['unit'],'icon'=>'Basket','status'=>'published','available'=>true,'created_at'=>now(),'updated_at'=>now()]);
   }
  }
 }
 public function down(): void {
  // Classification and catalogue additions are retained to preserve order references.
 }
};
