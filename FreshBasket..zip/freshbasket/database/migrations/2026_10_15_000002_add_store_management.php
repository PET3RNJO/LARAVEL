<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\{Schema,DB};
return new class extends Migration {
 public function up(): void {
  Schema::create('stores',function(Blueprint $t){$t->id();$t->string('name')->unique();$t->boolean('active')->default(true);$t->timestamps();});
  Schema::create('store_user',function(Blueprint $t){$t->id();$t->foreignId('store_id')->constrained()->cascadeOnDelete();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->timestamps();$t->unique(['store_id','user_id']);});
  Schema::table('products',function(Blueprint $t){$t->foreignId('store_id')->nullable()->constrained()->restrictOnDelete();$t->string('status')->default('published')->index();$t->text('description')->nullable();$t->string('image_path')->nullable();$t->text('review_reason')->nullable();});
  foreach(DB::table('products')->distinct()->pluck('store') as $name) {
   $id=DB::table('stores')->insertGetId(['name'=>$name,'active'=>true,'created_at'=>now(),'updated_at'=>now()]);
   DB::table('products')->where('store',$name)->update(['store_id'=>$id]);
  }
  Schema::create('store_audits',function(Blueprint $t){$t->id();$t->foreignId('actor_id')->constrained('users')->restrictOnDelete();$t->string('action');$t->string('target_type');$t->unsignedBigInteger('target_id');$t->json('details');$t->timestamp('created_at');});
 }
 public function down(): void {
  Schema::dropIfExists('store_audits');Schema::dropIfExists('store_user');
  Schema::table('products',function(Blueprint $t){$t->dropConstrainedForeignId('store_id');$t->dropColumn(['status','description','image_path','review_reason']);});Schema::dropIfExists('stores');
 }
};
