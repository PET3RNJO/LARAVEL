<?php
namespace Database\Seeders;
use App\Models\{Product,Store};
use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder {
 public function run(): void {
  if(Product::exists())return;
  foreach(['Shoprite','Pick n Pay'] as $name) {
   $store=Store::firstOrCreate(['name'=>$name]);
   foreach(config('catalogue.products') as $product=>$item) Product::create(['name'=>$product,'store'=>$name,'store_id'=>$store->id,'status'=>'published','category'=>$item['category'],'price'=>$item['price'],'unit'=>$item['unit'],'icon'=>$product==='Bananas'?"\u{1F34C}":'Basket','available'=>true]);
  }
 }
}
