<?php
namespace Tests\Feature;
use App\Models\{User,Store,Product};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;
class StoreManagementTest extends TestCase {
 use RefreshDatabase;
 private function admin(): User {$u=User::factory()->create();$u->forceFill(['is_admin'=>true])->save();return $u;}
 private function data(array $overrides=[]): array {return array_merge(['name'=>'Supplier rice','category'=>'Pantry','price'=>'29.95','unit'=>'1 kg','available'=>1,'submit'=>'pending'],$overrides);}
 private function product(Store $s,string $status='published'): Product {return Product::create(['name'=>'Store rice','store'=>$s->name,'store_id'=>$s->id,'status'=>$status,'price'=>2995,'unit'=>'1 kg','category'=>'Pantry','icon'=>'Basket']);}
 public function test_admin_creates_store_grants_and_revokes_registered_access(): void {
  $a=$this->admin();$u=User::factory()->create();$this->actingAs($a)->post('/admin/stores',['name'=>'New store'])->assertRedirect();$s=Store::first();
  $this->get('/admin/stores')->assertOk()->assertSee('New store');$this->post('/admin/stores/'.$s->id.'/members',['email'=>$u->email])->assertRedirect();
  $this->post('/admin/stores/'.$s->id.'/members',['email'=>$u->email])->assertRedirect();$this->assertDatabaseCount('store_user',1);$this->assertDatabaseCount('store_audits',2);
  $this->actingAs($u)->get('/supplier/stores/'.$s->id.'/products/create')->assertOk();
  $this->actingAs($a)->delete('/admin/stores/'.$s->id.'/members/'.$u->id,['reason'=>'Account removed'])->assertRedirect();
  $this->actingAs($u)->post('/supplier/stores/'.$s->id.'/products',$this->data())->assertForbidden();
 }
 public function test_customer_cannot_grant_access_or_self_assign_during_registration(): void {
  $s=Store::create(['name'=>'Private store']);$u=User::factory()->create();$this->actingAs($u)->post('/admin/stores',['name'=>'Bad store'])->assertForbidden();
  $this->post('/admin/stores/'.$s->id.'/members',['email'=>$u->email])->assertForbidden();$this->get('/admin/products')->assertForbidden();
  $this->get('/supplier')->assertOk()->assertSee('An administrator needs to assign');$this->post('/supplier/stores/'.$s->id.'/products',$this->data())->assertForbidden();
 }
 public function test_supplier_submission_review_edit_and_resubmission(): void {
  $s=Store::create(['name'=>'Supplier store']);$u=User::factory()->create();$s->users()->attach($u);$a=$this->admin();
  $this->actingAs($u)->post('/supplier/stores/'.$s->id.'/products',$this->data(['store_id'=>999,'status'=>'published','price'=>'29.95']))->assertRedirect('/supplier');$p=Product::first();
  $this->assertSame('pending',$p->status);$this->assertSame(2995,$p->price);$this->assertSame($s->id,$p->store_id);$this->get('/')->assertDontSee('Supplier rice');
  $this->actingAs($a)->get('/admin/products')->assertOk()->assertSee('Supplier rice');
  $this->patch('/admin/products/'.$p->id,['decision'=>'rejected'])->assertSessionHasErrors('reason');
  $this->patch('/admin/products/'.$p->id,['decision'=>'rejected','reason'=>'Please clarify size'])->assertRedirect();
  $this->actingAs($u)->get('/supplier')->assertSee('Please clarify size');
  $this->put('/supplier/stores/'.$s->id.'/products/'.$p->id,$this->data())->assertRedirect('/supplier');
  $this->actingAs($a)->patch('/admin/products/'.$p->id,['decision'=>'published'])->assertRedirect();
  $this->get('/')->assertSee('Supplier rice')->assertSee('K29.95');
  $this->actingAs($u)->get('/supplier/stores/'.$s->id.'/products/'.$p->id.'/edit')->assertOk();
  $this->put('/supplier/stores/'.$s->id.'/products/'.$p->id,$this->data(['submit'=>'draft','price'=>'30.01']))->assertRedirect('/supplier');
  $this->get('/')->assertDontSee('Supplier rice');$this->assertDatabaseHas('products',['id'=>$p->id,'price'=>3001,'status'=>'draft']);
 }
 public function test_supplier_cannot_access_another_stores_products_or_review(): void {
  $s=Store::create(['name'=>'First']);$other=Store::create(['name'=>'Other']);$u=User::factory()->create();$s->users()->attach($u);$p=$this->product($other,'pending');
  $this->actingAs($u)->get('/supplier/stores/'.$other->id.'/products/'.$p->id.'/edit')->assertForbidden();
  $this->put('/supplier/stores/'.$s->id.'/products/'.$p->id,$this->data())->assertNotFound();
  $this->put('/supplier/stores/'.$other->id.'/products/'.$p->id,$this->data())->assertForbidden();
  $this->patch('/admin/products/'.$p->id,['decision'=>'published'])->assertForbidden();
 }
 public function test_paused_stores_hide_products_and_block_checkout(): void {
  $s=Store::create(['name'=>'Pause me']);$u=User::factory()->create();$s->users()->attach($u);$p=$this->product($s);$a=$this->admin();
  $this->actingAs($u)->post('/cart/'.$p->id)->assertRedirect();$this->get('/checkout');$nonce=session('checkout_nonce');
  $this->actingAs($a)->patch('/admin/stores/'.$s->id,['active'=>0,'reason'=>'Temporarily unavailable'])->assertRedirect();
  $this->get('/')->assertDontSee('Store rice');$this->actingAs($u)->post('/cart/'.$p->id)->assertStatus(422);
  $this->post('/checkout',['phone'=>'+260971234567','address'=>'10 Main Road, Lusaka','checkout_token'=>$nonce])->assertStatus(422);
  $this->get('/supplier/stores/'.$s->id.'/products/create')->assertForbidden();$this->assertDatabaseCount('orders',0);
 }
 public function test_private_images_and_upload_validation(): void {
  Storage::fake('public');$s=Store::create(['name'=>'Photos']);$u=User::factory()->create();$s->users()->attach($u);$a=$this->admin();
  $this->actingAs($u)->post('/supplier/stores/'.$s->id.'/products',$this->data(['image'=>UploadedFile::fake()->create('code.php',1,'text/plain')]))->assertSessionHasErrors('image');
  $file=UploadedFile::fake()->image('rice.jpg');$this->post('/supplier/stores/'.$s->id.'/products',$this->data(['image'=>$file]))->assertRedirect();$p=Product::first();Storage::disk('public')->assertExists($p->image_path);
  $this->get('/products/'.$p->id.'/image')->assertOk();$this->actingAs(User::factory()->create())->get('/products/'.$p->id.'/image')->assertNotFound();
  $this->actingAs($a)->patch('/admin/products/'.$p->id,['decision'=>'published'])->assertRedirect();$this->post('/logout');$this->get('/products/'.$p->id.'/image')->assertOk();
 }
 public function test_unicode_is_not_mojibake_and_database_is_not_changed_by_test_setup(): void {
  $this->seed();$this->assertDatabaseCount('products',36);$html=$this->get('/')->assertOk()->assertSee('Bananas')->getContent();
  $this->assertStringNotContainsString('Ã',$html);$this->assertStringNotContainsString('Â',$html);$this->assertStringNotContainsString('ð',$html);$this->assertStringNotContainsString('@endsection',$html);
  $this->assertSame("\u{1F34C}",Product::where('name','Bananas')->first()->icon);
 }
 public function test_price_validation_does_not_allow_zero_or_fractional_ngwee(): void {
  $s=Store::create(['name'=>'Prices']);$u=User::factory()->create();$s->users()->attach($u);
  foreach(['0','1.001','-2','1e3'] as $price)$this->actingAs($u)->post('/supplier/stores/'.$s->id.'/products',$this->data(['price'=>$price]))->assertSessionHasErrors('price');
  $this->assertDatabaseCount('products',0);
 }
}
