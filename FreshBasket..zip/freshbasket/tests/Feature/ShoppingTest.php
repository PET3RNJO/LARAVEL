<?php
namespace Tests\Feature;
use App\Models\{User,Product,Order};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
class ShoppingTest extends TestCase {
 use RefreshDatabase;
 private function product(): Product {return Product::create(['name'=>'Milk','store'=>'Shoprite','store_id'=>\App\Models\Store::firstOrCreate(['name'=>'Shoprite'])->id,'category'=>'Dairy','price'=>3200,'unit'=>'1 litre','icon'=>'Milk']);}
 public function test_catalogue_and_filtering(): void {$this->product();$this->get('/')->assertOk()->assertSee('Milk');$this->get('/?q=unknown')->assertDontSee('K32.00');}
 public function test_registration_cannot_grant_admin_access(): void {$this->post('/register',['name'=>'Buyer','email'=>'buyer@example.com','password'=>'StrongPass123','password_confirmation'=>'StrongPass123','is_admin'=>true])->assertRedirect('/');$this->assertAuthenticated();$this->assertFalse((bool)User::first()->is_admin);}
 public function test_login_and_logout(): void {$u=User::factory()->create();$this->post('/login',['email'=>$u->email,'password'=>'password'])->assertRedirect('/orders');$this->assertAuthenticatedAs($u);$this->post('/logout')->assertRedirect('/');$this->assertGuest();}
 public function test_cart_quantity_and_removal(): void {$p=$this->product();$this->post('/cart/'.$p->id)->assertRedirect();$this->assertEquals(1,session('cart')[$p->id]);$this->patch('/cart/'.$p->id,['quantity'=>-1])->assertSessionHasErrors('quantity');$this->patch('/cart/'.$p->id,['quantity'=>0]);$this->get('/cart')->assertSee('A little empty');}
 public function test_guest_checkout_requires_login(): void {$this->get('/checkout')->assertRedirect('/login');$this->get('/admin')->assertRedirect('/login');}
 public function test_checkout_prices_and_duplicate_submission(): void {
  $u=User::factory()->create();$p=$this->product();$this->actingAs($u)->post('/cart/'.$p->id);$this->get('/checkout')->assertOk();$nonce=session('checkout_nonce');
  $data=['phone'=>'+260971234567','address'=>'10 Main Road, Lusaka','checkout_token'=>$nonce,'total'=>1];
  $this->post('/checkout',$data)->assertRedirect('/orders/1');$this->post('/checkout',$data)->assertRedirect('/orders/1');
  $this->assertDatabaseCount('orders',1);$this->assertDatabaseHas('orders',['total'=>6700,'subtotal'=>3200,'delivery_fee'=>3500]);
  $this->post('/cart/'.$p->id);$this->get('/checkout');$data['checkout_token']=session('checkout_nonce');$this->post('/checkout',$data)->assertRedirect('/orders/2');$this->assertDatabaseCount('orders',2);
 }
 public function test_unavailable_products_cannot_be_ordered(): void {$u=User::factory()->create();$p=$this->product();$this->actingAs($u)->post('/cart/'.$p->id);$this->get('/checkout');$nonce=session('checkout_nonce');$p->update(['available'=>false]);$this->post('/cart/'.$p->id)->assertStatus(422);$this->post('/checkout',['phone'=>'+260971234567','address'=>'10 Main Road, Lusaka','checkout_token'=>$nonce])->assertStatus(422);$this->assertDatabaseCount('orders',0);}
 private function order(User $u): Order {return Order::create(['user_id'=>$u->id,'items'=>[],'subtotal'=>100,'delivery_fee'=>3500,'total'=>3600,'phone'=>'+260971234567','address'=>'10 Main Road, Lusaka']);}
 public function test_order_ownership_and_admin_protection(): void {$owner=User::factory()->create();$other=User::factory()->create();$o=$this->order($owner);$this->actingAs($other)->get('/orders/'.$o->id)->assertForbidden();$this->get('/admin')->assertForbidden();$this->patch('/admin/orders/'.$o->id,['status'=>'confirmed'])->assertForbidden();$this->actingAs($owner)->get('/orders/'.$o->id)->assertOk();}
 public function test_admin_status_progression_and_terminal_protection(): void {$a=User::factory()->create();$a->forceFill(['is_admin'=>true])->save();$o=$this->order($a);$this->actingAs($a)->get('/admin')->assertOk();$this->patch('/admin/orders/'.$o->id,['status'=>'delivered'])->assertStatus(422);foreach(['confirmed','shopping','out_for_delivery','delivered'] as $s) $this->patch('/admin/orders/'.$o->id,['status'=>$s,'courier'=>'Manual courier'])->assertRedirect();$this->patch('/admin/orders/'.$o->id,['status'=>'placed'])->assertStatus(422);}
}
