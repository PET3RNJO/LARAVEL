<?php
namespace Tests\Feature;
use App\Models\{Product,Store,User};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
class SupermarketSectionsTest extends TestCase {
 use RefreshDatabase;
 public function test_sections_filter_products_and_preserve_store_selection(): void {
  $this->seed();$this->get('/')->assertOk()->assertSee('Fruit &amp; vegetables',false)->assertSee('Stationery')->assertSee('Deli &amp; fast food',false);
  $this->get('/?category=Stationery&store=Shoprite')->assertOk()->assertSee('Notebook and pencil set')->assertDontSee('<h3>Bananas</h3>',false)->assertSee('store=Shoprite',false);
  $this->get('/?category=Chilled%20%26%20frozen')->assertOk()->assertSee('Frozen mixed vegetables')->assertSee('Vanilla ice cream')->assertDontSee('<h3>Wholemeal bread</h3>',false);
 }
 public function test_all_sample_products_have_local_high_resolution_photos(): void {
  $this->seed();foreach(Product::all() as $p){$this->assertStringContainsString('/images/catalogue/',$p->catalogue_image);$path=public_path('images/catalogue/'.config('catalogue.products.'.$p->name.'.image').'.webp');$this->assertFileExists($path);$size=getimagesize($path);$this->assertGreaterThanOrEqual(1024,$size[0]);$this->assertGreaterThanOrEqual(1024,$size[1]);}
 }
 public function test_uploaded_supplier_photo_keeps_priority(): void {
  $s=Store::create(['name'=>'Photo store']);$p=Product::create(['name'=>'Custom rice','store_id'=>$s->id,'store'=>$s->name,'price'=>100,'unit'=>'1 kg','icon'=>'Basket','category'=>'Pantry','image_path'=>'products/custom.jpg']);
  $this->assertStringContainsString('/products/'.$p->id.'/image',$p->catalogue_image);
 }
 public function test_supplier_selects_valid_supermarket_section(): void {
  $s=Store::create(['name'=>'New store']);$u=User::factory()->create();$s->users()->attach($u);
  $this->actingAs($u)->get('/supplier/stores/'.$s->id.'/products/create')->assertOk()->assertSee('Supermarket section')->assertSee('Stationery');
  $data=['name'=>'Pens','price'=>'12.50','category'=>'Stationery','unit'=>'pack','available'=>1,'submit'=>'pending'];
  $this->post('/supplier/stores/'.$s->id.'/products',$data)->assertRedirect('/supplier');$this->assertDatabaseHas('products',['name'=>'Pens','category'=>'Stationery','status'=>'pending']);
  $data['category']='Invalid arbitrary section';$this->post('/supplier/stores/'.$s->id.'/products',$data)->assertSessionHasErrors('category');
 }
}
