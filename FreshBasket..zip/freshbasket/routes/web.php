<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController as Auth;
use App\Http\Controllers\ShopController as Shop;
use App\Http\Controllers\StoreController as Stores;
Route::get('/products/{product}/image',[Stores::class,'image']);
Route::get('/',[Shop::class,'index'])->name('home');
Route::get('/cart',[Shop::class,'cart']);
Route::post('/cart/{product}',[Shop::class,'add']);
Route::patch('/cart/{product}',[Shop::class,'update']);
Route::middleware('guest')->group(function(){
 Route::get('/login',fn() => app(Auth::class)->form('login'))->name('login');
 Route::get('/register',fn() => app(Auth::class)->form('register'));
 Route::post('/login',[Auth::class,'login'])->middleware('throttle:5,1');
 Route::post('/register',[Auth::class,'register'])->middleware('throttle:5,1');
});
Route::middleware('auth')->group(function(){
 Route::get('/supplier',[Stores::class,'dashboard']);
 Route::get('/supplier/stores/{store}/products/create',[Stores::class,'form']);
 Route::post('/supplier/stores/{store}/products',[Stores::class,'save']);
 Route::get('/supplier/stores/{store}/products/{product}/edit',[Stores::class,'form']);
 Route::put('/supplier/stores/{store}/products/{product}',[Stores::class,'save']);
 Route::get('/admin/stores',[Stores::class,'stores']);
 Route::post('/admin/stores',[Stores::class,'createStore']);
 Route::patch('/admin/stores/{store}',[Stores::class,'updateStore']);
 Route::post('/admin/stores/{store}/members',[Stores::class,'grant']);
 Route::delete('/admin/stores/{store}/members/{user}',[Stores::class,'revoke']);
 Route::get('/admin/products',[Stores::class,'reviews']);
 Route::patch('/admin/products/{product}',[Stores::class,'review']);
 Route::post('/logout',[Auth::class,'logout']);
 Route::get('/checkout',[Shop::class,'checkout']); Route::post('/checkout',[Shop::class,'place'])->middleware('throttle:10,1')->block(10,10);
 Route::get('/orders',[Shop::class,'orders']);Route::get('/orders/{order}',[Shop::class,'show']);
 Route::get('/admin',[Shop::class,'admin']);Route::patch('/admin/orders/{order}',[Shop::class,'status']);
});
