<?php
use Illuminate\Support\Facades\Artisan;
use App\Models\User;
Artisan::command('freshbasket:admin {email}', function() {
 $u=User::where('email',$this->argument('email'))->first();
 if(!$u) { $this->error('Register this email in the app first.');return 1; }
 $u->forceFill(['is_admin'=>true])->save();$this->info('Admin access enabled.');
})->purpose('Grant admin access to an existing registered account');
