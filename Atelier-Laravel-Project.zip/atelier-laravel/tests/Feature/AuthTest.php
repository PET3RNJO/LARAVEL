<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_pages_render(): void
    {
        foreach (['/', '/login', '/register'] as $url) {
            $this->get($url)->assertOk();
        }
    }

    public function test_dashboard_requires_login(): void
    {
        $this->get('/dashboard')->assertRedirect('/login');
    }

    public function test_registration_saves_a_hashed_password_and_logs_in(): void
    {
        $this->post('/register', ['name' => 'Peter', 'email' => 'Peter@example.com', 'password' => 'studio12345', 'password_confirmation' => 'studio12345'])->assertRedirect('/dashboard');
        $user = User::firstOrFail();
        $this->assertSame('peter@example.com', $user->email);
        $this->assertTrue(Hash::check('studio12345', $user->password));
        $this->assertAuthenticatedAs($user);
        $this->get('/dashboard')->assertOk()->assertSee('Peter');
    }

    public function test_duplicate_email_is_rejected(): void
    {
        User::factory()->create(['email' => 'peter@example.com']);
        $this->post('/register', ['name' => 'Peter', 'email' => 'PETER@example.com', 'password' => 'studio12345', 'password_confirmation' => 'studio12345'])->assertSessionHasErrors('email');
        $this->assertDatabaseCount('users', 1);
        $this->assertGuest();
    }

    public function test_password_confirmation_is_required(): void
    {
        $this->post('/register', ['name' => 'Peter', 'email' => 'peter@example.com', 'password' => 'studio12345', 'password_confirmation' => 'different'])->assertSessionHasErrors('password');
        $this->assertDatabaseCount('users', 0);
    }

    public function test_short_password_is_rejected(): void
    {
        $this->post('/register', ['name' => 'Peter', 'email' => 'peter@example.com', 'password' => 'short', 'password_confirmation' => 'short'])->assertSessionHasErrors('password');
    }

    public function test_correct_credentials_log_in(): void
    {
        $user = User::factory()->create(['email' => 'peter@example.com', 'password' => Hash::make('studio12345')]);
        $this->post('/login', ['email' => 'PETER@example.com', 'password' => 'studio12345', 'remember' => '1'])->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
    }

    public function test_invalid_password_does_not_log_in(): void
    {
        User::factory()->create(['email' => 'peter@example.com']);
        $this->post('/login', ['email' => 'peter@example.com', 'password' => 'incorrect'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_logout_ends_authentication(): void
    {
        $this->actingAs(User::factory()->create())->post('/logout')->assertRedirect('/');
        $this->assertGuest();
        $this->get('/dashboard')->assertRedirect('/login');
    }

    public function test_logout_is_post_only(): void
    {
        $this->actingAs(User::factory()->create())->get('/logout')->assertStatus(405);
    }

    public function test_authenticated_visitors_are_redirected_from_auth_forms(): void
    {
        $this->actingAs(User::factory()->create());
        $this->get('/login')->assertRedirect('/dashboard');
        $this->get('/register')->assertRedirect('/dashboard');
    }

    public function test_login_attempts_are_rate_limited(): void
    {
        for ($i = 0; $i < 6; $i++) {
            $this->post('/login', ['email' => 'absent@example.com', 'password' => 'wrong'])->assertSessionHasErrors('email');
        }
        $this->post('/login', ['email' => 'absent@example.com', 'password' => 'wrong'])->assertStatus(429);
    }

    public function test_dashboard_escapes_user_input(): void
    {
        $this->actingAs(User::factory()->create(['name' => '<script>alert(1)</script>']))->get('/dashboard')->assertOk()->assertDontSee('<script>alert(1)</script>', false)->assertSee('&lt;script&gt;', false);
    }
}
