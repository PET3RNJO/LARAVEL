@extends('layouts.app')
@section('title', 'Create an account')
@section('content')
<section class="auth-shell"><div class="auth-story"><p class="eyebrow">MAKE YOURSELF AT HOME</p><h1>A new<br><em>chapter.</em></h1><p>Your personal space in the studio.</p><img src="{{ asset('images/dress.svg') }}" alt="Illustrated terracotta dress"></div><div class="auth-card"><p class="eyebrow">JOIN THE STUDIO</p><h2>Start your story.</h2><p>Create your free account.</p>
<form method="POST" action="{{ route('register.store') }}">@csrf
<label for="name">Your name</label><input id="name" name="name" value="{{ old('name') }}" maxlength="100" autocomplete="name" required autofocus @error('name') aria-invalid="true" aria-describedby="name-error" @enderror>@error('name')<p class="error" id="name-error">{{ $message }}</p>@enderror
<label for="email">Email address</label><input id="email" name="email" type="email" value="{{ old('email') }}" maxlength="254" autocomplete="email" required @error('email') aria-invalid="true" aria-describedby="email-error" @enderror>@error('email')<p class="error" id="email-error">{{ $message }}</p>@enderror
<label for="password">Password <small>(8–72 characters)</small></label><input id="password" name="password" type="password" minlength="8" maxlength="72" autocomplete="new-password" required @error('password') aria-invalid="true" aria-describedby="password-error" @enderror>@error('password')<p class="error" id="password-error">{{ $message }}</p>@enderror
<label for="password_confirmation">Confirm password</label><input id="password_confirmation" name="password_confirmation" type="password" minlength="8" maxlength="72" autocomplete="new-password" required>
<button class="button" type="submit">Create account <span>↗</span></button></form><p class="form-foot">Already a member? <a href="{{ route('login') }}">Log in</a></p></div></section>
@endsection
