@extends('layouts.app')
@section('title', 'Log in')
@section('content')
<section class="auth-shell"><div class="auth-story"><p class="eyebrow">WELCOME TO THE ATELIER</p><h1>Your style.<br>Your <em>space.</em></h1><p>A small studio. A world of possibility.</p><img src="{{ asset('images/shirt.svg') }}" alt="Illustrated relaxed shirt"></div><div class="auth-card"><p class="eyebrow">YOUR STUDIO ACCOUNT</p><h2>Welcome back.</h2><p>Log in to your personal space.</p>
<form method="POST" action="{{ route('login.store') }}">@csrf
<label for="email">Email address</label><input id="email" name="email" type="email" value="{{ old('email') }}" autocomplete="email" required autofocus @error('email') aria-invalid="true" aria-describedby="email-error" @enderror>@error('email')<p class="error" id="email-error">{{ $message }}</p>@enderror
<label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required @error('password') aria-invalid="true" aria-describedby="password-error" @enderror>@error('password')<p class="error" id="password-error">{{ $message }}</p>@enderror
<label class="check"><input type="checkbox" name="remember" value="1" @checked(old('remember'))> Remember me on this device</label>
<button class="button" type="submit">Log in <span>↗</span></button></form><p class="form-foot">New here? <a href="{{ route('register') }}">Create an account</a></p></div></section>
@endsection
