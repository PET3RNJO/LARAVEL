<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Atelier Studio — thoughtful clothing, distinctive silhouettes and personal style.">
    <title>@yield('title', 'Atelier Studio') · Atelier Studio</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
    <a class="brand" href="{{ route('home') }}">ATELIER<span>STUDIO / EST. 2026</span></a>
    <nav aria-label="Main navigation">
        <a href="{{ route('home') }}#collection">Collection</a>
        <a href="{{ route('home') }}#about">Our story</a>
        @auth
            <a href="{{ route('dashboard') }}">My account</a>
            <form method="POST" action="{{ route('logout') }}">@csrf<button class="nav-button" type="submit">Log out ↗</button></form>
        @else
            <a href="{{ route('login') }}">Log in</a>
            <a class="nav-button" href="{{ route('register') }}">Join the studio ↗</a>
        @endauth
    </nav>
</header>
@if(session('status'))<div class="notice" role="status">{{ session('status') }}</div>@endif
<main id="main">@yield('content')</main>
<footer><a class="brand" href="{{ route('home') }}">ATELIER</a><p>Made with intention. Worn your way.</p><small>© {{ date('Y') }} Atelier Studio</small></footer>
</body>
</html>
