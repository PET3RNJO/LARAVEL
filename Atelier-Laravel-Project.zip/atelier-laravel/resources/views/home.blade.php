@extends('layouts.app')
@section('title', 'Clothing with character')
@section('content')
<section class="hero">
    <div class="hero-copy"><p class="eyebrow">INDEPENDENT DESIGN / EVERYDAY EXPRESSION</p><h1>Wear your<br>own <em>story.</em></h1><p class="intro">Thoughtful clothing for people who do things their own way. Designed with care. Made to feel like you.</p><a class="button" href="#collection">Explore the collection <span>↗</span></a><div class="hero-note"><span class="dot"></span> The first chapter / Studio collection 01</div></div>
    <div class="hero-art"><img src="{{ asset('images/coat.svg') }}" alt="Illustration of a sculptural olive coat"><div class="art-label"><span>01 / THE SIGNATURE COAT</span><span>FORM. TEXTURE. CHARACTER.</span></div><span class="art-badge">THE<br>STUDIO<br>EDIT</span></div>
</section>
<div class="ribbon"><span>SMALL COLLECTIONS</span><span>✳</span><span>CONSIDERED DETAILS</span><span>✳</span><span>INDIVIDUAL STYLE</span><span>✳</span><span>DESIGNED WITH INTENTION</span></div>
<section id="collection" class="section"><div class="section-heading"><div><p class="eyebrow">THE STUDIO EDIT / 01</p><h2>A few good pieces.</h2></div><p>Distinctive silhouettes.<br>Room to make them your own.</p></div><div class="collection-grid">
@foreach([['coat', 'The signature coat', 'Sculptural layers / Olive'], ['dress', 'The everyday dress', 'Easy movement / Terracotta'], ['shirt', 'The relaxed shirt', 'Quiet structure / Warm ivory']] as $piece)
<article class="piece"><div class="piece-art {{ $piece[0] }}"><img src="{{ asset('images/'.$piece[0].'.svg') }}" alt="Illustration of {{ strtolower($piece[1]) }}" loading="lazy"></div><div class="piece-caption"><div><h3>{{ $piece[1] }}</h3><p>{{ $piece[2] }}</p></div><span aria-hidden="true">↗</span></div></article>
@endforeach
</div></section>
<section id="about" class="story"><p class="eyebrow">A NOTE FROM THE STUDIO</p><h2>Good design starts<br>with <em>a feeling.</em></h2><div><p>Atelier is a small fashion design studio built around a simple idea: the best clothes help you feel more like yourself.</p><p>We explore shape, colour and texture to create a collection with character. This is our first chapter. Make it part of yours.</p><a class="text-link" href="{{ route('register') }}">Create your studio account ↗</a></div></section>
<section class="join"><p class="eyebrow">YOUR NEXT CHAPTER</p><h2>A little more you.</h2><p>Create an account and find your place in the studio.</p><a class="button" href="{{ route('register') }}">Join the studio <span>↗</span></a></section>
@endsection
